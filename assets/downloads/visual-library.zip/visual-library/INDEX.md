# The Visual Library — index

Companion plates to **THE $1M DESIGN SYSTEM** by Jiranan Oh. Twenty-four original diagrams in the book's black / white / red editorial system. These are explanatory models and reference plates — not screenshots of real products and not empirical charts. Use them to *think*, then design to your own tokens.

The full set is also compiled in `THE-1M-DESIGN-SYSTEM-Visual-Library.pdf`.

## Concept diagrams (the book's method)
1. **figure-01 — Threshold leak** · where attention drains between impression and purchase.
2. **figure-02 — Seven conversion gaps** · the seven causes that all produce one symptom: no sale.
3. **figure-03 — Feature alibi** · why a feature earns building only when evidence connects it to blocked value.
4. **figure-04 — Starting situation** · the "you shipped, then silence" moment the book begins from.
5. **figure-05 — Positioning anatomy** · the parts of a position statement that make a product obvious.
6. **figure-06 — Page argument** · reading a landing page as a sequence of claims, not sections.
7. **figure-07 — Product world** · the world a product implies, beyond its feature list.
8. **figure-08 — Design vocabulary** · naming the regions you are directing (nav, hero, primary action, proof, modules).
9. **figure-09 — Elements before the page** · finish the components before you compose the page.
10. **figure-10 — Trust ladder** · the rungs a visitor climbs from doubt to action.
11. **figure-11 — Proof spectrum** · from weakest (adjectives) to strongest (commercial evidence).
12. **figure-12 — One-promise system** · one promise, carried consistently across the whole product.
13. **figure-13 — AI memory stack** · the seven kit files that give an AI session a durable memory.
14. **figure-14 — Signal loop** · turning observed behavior back into the next smallest test.

## Reference plates (patterns, done right vs. wrong)
15. **figure-15 — Three hero patterns** · centered, split, and product-led hero layouts.
16. **figure-16 — Interface patterns** · common app-screen structures worth studying.
17. **figure-17 — Four public decisions** · study the decision behind four well-known products, not their surface.
18. **figure-18 — Landing-page anatomy** · the standard blocks of a page that sells.
19. **figure-19 — Proof block** · how to compose a credible evidence section.
20. **figure-20 — Empty state** · the first-run screen as an onboarding argument.
21. **figure-21 — Pricing card** · a pricing unit the buyer can actually parse.

## Glossary plates (a term, shown)
22. **figure-22 — Bento grid** · use bento for related capabilities, not to fill space.
23. **figure-23 — Glassmorphism** · transparency as a purposeful overlay, not a whole identity.
24. **figure-24 — Comparison table** · a table the buyer trusts beats a table you win.

---
Every plate follows the book's rule: borrow the *decision*, not the look. Restyle to your own brand, and never present a diagram as measured data.
