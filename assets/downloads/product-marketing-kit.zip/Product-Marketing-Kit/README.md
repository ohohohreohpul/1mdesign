# Product Marketing Kit

The companion kit to **THE $1M DESIGN SYSTEM** by Jiranan Oh. It turns the book's six decisions into durable project context — files that travel with your product so an AI session stops re-deciding your strategy every time you open a new chat.

The idea from Chapter 13: the founder remembers the buyer, the rejected concepts, the brand rules, and the claims that lack evidence. The model sees only the current prompt. These files give the model a memory.

---

## What's in the box

```
product-marketing-kit/
├── README.md                 ← you are here
├── CONTEXT-HEADER.md         ← paste this above every AI task; how to load files into Claude/Cursor/v0
├── COMMAND-LIBRARY.md        ← every AI command from the book, grouped by stage
├── RESOURCE-DIRECTORY.md     ← ~90 web-verified design + AI-tool sources, organized by job
├── DESIGN-TREASURES.md       ← the 15 highest-leverage resources, with how to use each with your AI
├── starters/                 ← FILL THESE for your own product (7 blank templates)
│   ├── POSITIONING.md
│   ├── PRODUCT-COPY.md
│   ├── CREATIVE-DIRECTION.md
│   ├── DESIGN-SYSTEM.md
│   ├── PRODUCT-PROOF.md
│   ├── LANDING-PAGE-BRIEF.md
│   └── AI-CREATIVE-QA.md
└── example-relay/            ← REFERENCE ONLY: the same 7 files completed for the book's example product, "Relay"
    └── (same 7 filenames)
```

**`starters/` are yours to fill.** Each file uses the section structure the book specifies, with `>` fill-in prompts and a one-line note on what "good" looks like. Delete the prompt lines as each decision becomes final.

**`example-relay/` is a finished worked example.** "Relay" is the fictional screen-demo editor the book rebuilds chapter by chapter. Read these to see how a completed file reads — then close them and write your own. Do not copy Relay's answers; copy the level of specificity.

---

## How to use it with your AI

1. Open `CONTEXT-HEADER.md` and copy the context header.
2. Attach or reference the completed `starters/` files a task needs (the header explains how, per tool).
3. Pick a command from `COMMAND-LIBRARY.md` for the stage you're working through.
4. Paste header + command, run it, and judge the output against your files — it's a draft, not an answer.
5. When you decide, record it: update the affected file, remove obsolete instructions, and log the decision (see `CONTEXT-HEADER.md`).
6. Before shipping any asset, run `starters/AI-CREATIVE-QA.md`.

Reach for `RESOURCE-DIRECTORY.md` when a task needs a real design-system source or the right tool for a job (image, video, upscale, orchestration, analytics). New here? Open `DESIGN-TREASURES.md` first — it's the short, curated shortlist. Every tool entry is a starting point — verify licenses and commercial-use terms yourself.

---

## The order to work through the files (the book's six decisions)

Work top to bottom. Each decision feeds the next, and the last file checks all of them.

1. **Find the break** — locate where attention stops becoming understanding, trust, or action. *(Start with the diagnose commands; no file to fill yet.)*
2. **Choose the reason to buy** → `POSITIONING.md`
3. **Say it plainly** → `PRODUCT-COPY.md`
4. **Give the product a direction** → `CREATIVE-DIRECTION.md`, then `DESIGN-SYSTEM.md`
5. **Prove it** → `PRODUCT-PROOF.md`
6. **Make everything agree** → `LANDING-PAGE-BRIEF.md`, checked with `AI-CREATIVE-QA.md`
7. **Learn from real behavior** — watch where people hesitate, then repair that part and update the affected files. *(Use the learn commands.)*

---

## The house rules the whole kit runs on

- Source decisions from evidence, not from adjectives.
- Never invent customers, numbers, logos, testimonials, integrations, or outcomes.
- Every promise needs a mechanism; every material claim needs evidence or a stated limit.
- Banned words unless they carry indispensable factual information: revolutionize, unlock, seamless, supercharge, game-changing, next-generation, effortless, AI-powered.
- Keep a human approval gate at the end of every AI pipeline.
