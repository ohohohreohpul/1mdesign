# PRODUCT-PROOF.md

> Worked example — the fictional product "Relay" from THE $1M DESIGN SYSTEM. Use it as a reference for how a completed file reads. Your own version lives in `../starters/PRODUCT-PROOF.md`.

| Claim | Buyer doubt | Evidence | Format | Limitation |
|---|---|---|---|---|
| Edit without a timeline | Will I still need editing skills? | Delete transcript text and show corresponding cut | Live sample | Advanced frame editing is not available |
| Preserve the real interface | Will AI invent UI? | Source and export side by side | Fidelity comparison | Cursor and captions are added |
| Publish faster | How much time is actually saved? | Timed example under stated conditions | Annotated demo | Depends on recording length and review |
| Try before paying | Will I see useful output first? | Complete sample workflow | Sandbox | Own-file export may require account |
| Files are handled responsibly | What happens to confidential recordings? | Plain policy and deletion behavior | Upload note + policy | Must match actual infrastructure |

## Demonstration record

Input: forty-seven-second recording of a real fictional product flow.
Output: twenty-four-second edited demo.
Edits shown: repeated sentence removed, opening pause shortened, captions added, cursor emphasis added, vertical crop previewed.
What it proves: the current product can perform those specific edits.
What it does not prove: universal time savings, increased conversion, or suitability for every recording.
