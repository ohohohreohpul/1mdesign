# PRODUCT-PROOF.md

> Worked example — the fictional product "Relay" from THE $1M DESIGN SYSTEM. A *completed* proof file: each claim tied to a specific buyer doubt, a real evidence artifact, and an honest confidence level. Your own version lives in `../starters/PRODUCT-PROOF.md`. Copy the discipline, not Relay's answers.

Proof is not adjectives. It is a specific artifact that answers a specific doubt, marked with how strong the evidence actually is. Relay is an early product, so most evidence here is a **capability demonstration** (it proves the product *can do X*), not commercial proof (that *customers buy because of X*). Saying which is which is the whole job.

## Evidence confidence scale (from Chapter 11)

`0` assumption · `1` isolated signal · `2` repeated qualitative pattern · `3` behavioral pattern · `4` controlled comparison · `5` commercial evidence.
Relay may only honestly claim **0–2** today. Every row below states its level.

## Claims ledger

| Claim | Buyer's real doubt | Evidence artifact | Format | Confidence | Stated limitation |
|---|---|---|---|---|---|
| Edit without a timeline | "Will I still need editing skills?" | Delete a sentence in the transcript; the matching clip is removed on screen | Live sample, no account | `2` capability | Frame-level and multi-track editing are not available |
| It preserves the real interface | "Will the AI invent or fake my UI?" | Source recording and export shown side by side, same frames | Fidelity comparison | `2` capability | Captions and cursor emphasis are added on top; nothing else is altered |
| It publishes the useful moment faster | "How much time is *actually* saved?" | One timed run under stated conditions (below) | Annotated demo | `1` single example | Depends on recording length and how much review you do |
| You can try before paying | "Will I see useful output before a card?" | The full sample workflow runs pre-account | Sandbox | `2` capability | Exporting *your own* file may require an account |
| Files are handled responsibly | "What happens to a confidential recording?" | The deletion policy shown inline at upload | Policy note beside dropzone | `0→must match infra` | Only true once infrastructure enforces it — do not claim before then |

## Demonstration record (the one timed example)

- **Input:** a 47-second raw screen recording of a real (fictional) product flow.
- **Output:** a 24-second edited demo.
- **Edits shown:** one repeated sentence removed · opening dead pause shortened · captions added · cursor emphasis added · vertical crop previewed.
- **Conditions:** single reviewer, one pass, no re-recording. Stated on the asset so the number can't be read as a universal guarantee.
- **What it proves:** the current product performs *those specific edits* on *that recording*.
- **What it does NOT prove:** universal time savings, higher conversion, or fit for every recording. Do not imply any of these.

## Where proof sits on the page

The fidelity comparison goes **above** the pricing section — the buyer's loudest doubt ("will it fake my product?") is answered before they're asked to pay. The timed demo sits inside the mechanism section, not the hero (a number in the hero reads as a claim; beside the mechanism it reads as evidence).

## Claims we explicitly cannot make yet

- "Saves you hours" (no controlled comparison → would be level 4; we're at 1).
- "Founders convert better with Relay demos" (no commercial evidence → level 5).
- Any testimonial, logo, or user count. None exist. Inventing one is the fastest way to lose the trust this file protects.

## House rule

Every claim on the live page must trace to a row here. If a claim has no row, it has no evidence — cut it or downgrade the language ("we've seen an early signal that…", not "customers want…").
