# CREATIVE-DIRECTION.md

> Worked example — the fictional product "Relay" from THE $1M DESIGN SYSTEM. Use it as a reference for how a completed file reads. Your own version lives in `../starters/CREATIVE-DIRECTION.md`.

## Direction

Make solo developers feel commercially equipped by presenting Relay as the final publishing instrument between a finished feature and its launch, proven through annotated before-and-after recordings and expressed with editorial precision rather than AI spectacle.

## Intended belief

Relay removes dead time and friction without fabricating the product.

## Visual behavior

- Use real source and output frames.
- Make editing marks, transcript selections, cursor paths, and time removed visible.
- Use typography to create pace.
- Keep surfaces neutral so evidence carries the accent.
- Use cobalt for action and selected transcript.
- Use acid lime sparingly to mark verified improvement.

## Language behavior

- Concrete verbs: record, delete, review, preview, export.
- Short declarative headings.
- No magical transformation language.
- Explain AI through product behavior, not model mythology.

## Exclusions

- no glowing AI orb
- no purple gradient as category shorthand
- no generated product UI
- no floating feature icons
- no stock creator celebrating at a laptop
- no "create without limits"
- no "revolutionary," "effortless," or "studio-quality" without a defined condition
