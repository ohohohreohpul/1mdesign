# CREATIVE-DIRECTION.md

> Worked example — the fictional product "Relay" from THE $1M DESIGN SYSTEM. A *completed* creative direction: a single intended belief, made concrete in how things look and read. Your own version lives in `../starters/CREATIVE-DIRECTION.md`.

## The one belief this direction must create

**"Relay removes the dead time between a finished feature and the video that sells it — without faking the product."**

Everything below exists to make a solo developer feel *commercially equipped*, not *entertained by AI*. If a creative choice doesn't serve that belief, it's wrong even if it looks good.

## Direction in one line

Present Relay as the final publishing instrument between working software and its launch — proven through annotated before/after recordings, expressed with editorial precision rather than AI spectacle.

## Visual behavior (concrete)

- **The footage is the hero.** The UI is dark (`--canvas` graphite) so the buyer's own product recording is the brightest thing on screen. Chrome recedes; evidence advances.
- **Show the mechanism, not magic.** Make editing marks visible: transcript selections in `--action` cobalt, removed spans, cursor paths, seconds cut. The viewer should *see* the edit happen.
- **Accent carries meaning, not decoration.** `--action` = you can act / this is selected. `--verified` acid lime = a confirmed cut or completed export, nothing else.
- **Comparison is the signature device.** A source→export toggle or side-by-side appears on nearly every asset. The product's honesty *is* the aesthetic.
- **Typography sets pace.** Compact display headings, generous negative space, one hero statement per view. Calm, not busy.

## Reference mood (direction, not to copy)

- Editorial software marketing where the product screen is the centerpiece (think restrained, product-led SaaS hero, not lifestyle stock).
- Documentary before/after, not advertising gloss.
- Motion that is slow and locked — a confident product doesn't need frantic cuts.

## Language behavior

- **Concrete verbs only:** record, delete, review, preview, export. Never "transform," "unleash," "reimagine."
- Short declarative headings; the copy explains the AI *through product behavior*, never model mythology.
- Every sentence could be read aloud to a skeptical developer without embarrassment.

## Exclusions (auto-reject an asset if it has any of these)

- glowing AI orb, neural-network filigree, or "brain" iconography
- purple/blue gradient used as generic "AI category" shorthand
- any generated or fictional version of the product UI
- floating disconnected feature icons
- stock "creator celebrating at a laptop"
- copy like "create without limits," "revolutionary," "effortless," or "studio-quality" without a defined, stated condition
- a hero number presented as a claim with no evidence beside it

## The test

Before anything ships: *does this make the buyer trust the product more, or just find it cooler?* Trust wins every time.
