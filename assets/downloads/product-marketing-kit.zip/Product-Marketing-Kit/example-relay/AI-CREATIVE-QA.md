# AI-CREATIVE-QA.md

> Worked example — the fictional product "Relay" from THE $1M DESIGN SYSTEM. Use it as a reference for how a completed file reads. Your own version lives in `../starters/AI-CREATIVE-QA.md`.

Before shipping an asset:

- Does it speak to a founder with a feature ready to launch?
- Does it preserve the screen-demo category?
- Does it carry the "real product, less dead time" belief?
- Is every interface frame real and current?
- Are product changes limited to editing behavior Relay actually performs?
- Are timing claims measured under stated conditions?
- Are file-handling statements technically accurate?
- Does cobalt indicate action and lime indicate verified change?
- Does the asset avoid the excluded AI category clichés?
- Can a mobile viewer understand the core evidence?
- Is text readable and keyboard focus visible?
- Are sources, permissions, and output rights recorded?

## Why the pack matters

Any competent tool can now generate a Relay-shaped page.

The pack makes it harder to generate the wrong Relay.

That is the shift this book asks you to make: from prompting for outputs to maintaining a system of commercial and creative decisions.
