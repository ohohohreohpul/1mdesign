# AI-CREATIVE-QA.md

> Worked example — the fictional product "Relay" from THE $1M DESIGN SYSTEM. A *completed* pre-ship QA: concrete gates, each with a pass condition and a block-ship trigger. Run this on every asset before it goes live. Your own version lives in `../starters/AI-CREATIVE-QA.md`.

Any competent tool can now generate a Relay-shaped page. This checklist exists to stop it from shipping the *wrong* Relay. Each item is a gate: it **passes** or it **blocks ship**.

## 1. Message & positioning
- [ ] Speaks to a solo founder with a feature ready to launch (not "creators" in general). — *block if the audience is generic.*
- [ ] Preserves the screen-demo-editor category. — *block if it drifts to "AI video generator."*
- [ ] Carries the one belief: "real product, less dead time." — *block if the belief is absent or contradicted.*

## 2. Truth & evidence (the non-negotiable gates)
- [ ] Every interface frame shown is the **real, current** product. — *block on any invented or mocked UI.*
- [ ] Product changes shown are limited to edits Relay actually performs (cut, caption, cursor, crop). — *block if it implies frame-level or multi-track editing.*
- [ ] Every timing/quantity claim is measured under stated conditions and traces to a `PRODUCT-PROOF` row. — *block on any unbacked number.*
- [ ] File-handling statements match real infrastructure. — *block if the policy isn't enforced yet.*
- [ ] No invented testimonials, logos, user counts, or integrations. — *block on any fabricated proof.*

## 3. Brand & design system
- [ ] Uses only `DESIGN-SYSTEM.md` tokens — no unlisted colors, fonts, radii, or sizes. — *block on off-token styling.*
- [ ] Cobalt = action/selected; acid lime = verified/complete only. — *block if lime is used as decoration.*
- [ ] Avoids every item on the `CREATIVE-DIRECTION.md` exclusion list (AI orb, purple gradient, generated UI, etc.). — *block on any cliché.*

## 4. Accessibility & craft
- [ ] Text contrast ≥ 4.5:1 (≥ 3:1 for ≥24px). — *block on failing contrast.*
- [ ] Visible focus ring on every interactive element; the core task is fully keyboard-operable. — *block if keyboard path breaks.*
- [ ] `prefers-reduced-motion` honored; nothing critical depends on hover or autoplay. — *block otherwise.*
- [ ] Defined loading / error / success / empty states for every async action. — *block on a dead-end state.*

## 5. Mobile
- [ ] Core evidence (headline, first comparison frame, sample action) is understandable before the first major scroll. — *block if the value is below the fold.*
- [ ] The comparison works as a controlled toggle, not hover. — *block otherwise.*

## 6. Rights & provenance
- [ ] Sources, permissions, and output rights for any generated asset are recorded. — *block if provenance is unknown.*

---

## Why this pack matters

The shift the book asks for: from *prompting for outputs* to *maintaining a system of commercial and creative decisions.* These files are that system; this checklist is its final gate. A human runs it — the last approval never belongs to the model.
