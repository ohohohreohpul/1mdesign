# POSITIONING.md

> Worked example — the fictional product "Relay" from THE $1M DESIGN SYSTEM. Use it as a reference for how a completed file reads. Your own version lives in `../starters/POSITIONING.md`.

## Product

**Name:** Relay
**Category:** Screen-demo editor
**Factual description:** Relay edits screen recordings through their transcript and exports short product-demo formats.

## Primary buyer

**Person:** Solo SaaS founder
**Situation:** A feature is ready to announce, but the demo is not.
**Trigger:** The founder is preparing a launch post, changelog, email, or listing.
**Current behavior:** Record multiple takes, send a rough Loom, edit manually in a timeline, or delay the announcement.
**Cost:** The feature loses launch momentum; the recording makes the product feel less finished; editing becomes a second project.
**Desired progress:** Publish a clear product demo while the feature is still new.

## Position

For solo SaaS founders announcing a feature, Relay is a screen-demo editor that turns a rough recording into a clean launch video without a timeline, unlike general video editors, because founders edit the transcript while Relay preserves the real product interface.

## First value

The user removes one mistake or dead section by deleting words from the transcript and immediately sees the corrected preview.

## Boundaries

Relay is designed for screen demos. It is not a cinematic text-to-video generator, avatar platform, or full professional timeline editor.

It does not promise that every recording becomes a successful launch. It helps turn an existing recording into a clearer artifact.
