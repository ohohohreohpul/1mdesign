# LANDING-PAGE-BRIEF.md

> Worked example — the fictional product "Relay" from THE $1M DESIGN SYSTEM. A *completed* brief: every section has a job, its evidence, and a pass/fail acceptance line. Your own version lives in `../starters/LANDING-PAGE-BRIEF.md`. This file is what you hand to v0 / Lovable / Cursor — it assumes `POSITIONING`, `PRODUCT-COPY`, `DESIGN-SYSTEM`, and `PRODUCT-PROOF` are already decided.

## Page job

Get a solo SaaS founder preparing a feature announcement to: understand Relay in five seconds, inspect real output, and try the sample — in that order. One primary action: **Try the sample.**

## Section-by-section spec

Each section: **job · content · evidence it carries · acceptance (pass/fail).**

1. **Hero** — *job:* name the category + outcome instantly. *content:* headline "Ship the demo while the feature is still new," subhead, `Try the sample` (primary) + `Upload a recording` (secondary), trust line "Your interface stays real." *evidence:* the first frame of the before/after preview, visible without scroll. *accept:* a five-second viewer can say "it edits screen demos." Fail if the hero needs reading to be understood.
2. **Interactive sample** — *job:* first value before any signup. *content:* the pre-loaded 47s recording, editable. *evidence:* the product itself working. *accept:* a visitor reaches an edited preview with no account and no card.
3. **The launch moment** — *job:* make them feel the problem. *content:* "You finished the hard part; the first take wanders." *evidence:* none needed (situation, not claim). *accept:* the described moment is specific enough to be *their* moment.
4. **Mechanism** — *job:* show *how*, not magic. *content:* record → edit the transcript → publish, each with the visible edit. *evidence:* the timed 47s→24s demo (from `PRODUCT-PROOF`), labeled with conditions. *accept:* the mechanism is legible without motion or hover.
5. **Fidelity comparison** — *job:* kill the loudest doubt ("will it fake my UI?"). *content:* source vs export, same frames. *evidence:* the comparison artifact (confidence `2`). *accept:* sits **above** pricing; works as a toggle on mobile.
6. **Three outcome-led capabilities** — *job:* translate features into progress. *content:* three, outcome-first. *accept:* each names a result, not a feature spec.
7. **File handling** — *job:* answer the privacy doubt at the moment it arises. *content:* deletion policy in plain language. *accept:* the statement matches real infrastructure or it does not ship.
8. **Fit & limits** — *job:* honest boundaries build trust. *content:* what Relay is/ isn't (no cinematic gen, no avatars). *accept:* a real "not for you" is stated.
9. **Pricing** — *job:* convert intent. *content:* one-off export vs repeat-use, side by side; free sample export path visible first. *accept:* price is parseable in one read; no dark-pattern default.
10. **Final action** — *job:* one more low-risk yes. *content:* "Edit the sample recording." *accept:* repeats the primary action, not a new ask.

## Mobile priority (before the first major scroll)

Headline · subhead · first comparison frame · sample action. The side-by-side becomes a controlled toggle; essential evidence never depends on hover or drag.

## Acceptance criteria for the whole page (tie to Chapter 14 thresholds)

- **Comprehension:** ≥ most five-second testers name "screen-demo editing." *(threshold: comprehension)*
- **Truth:** every visible UI frame is the current product; no claim lacks a `PRODUCT-PROOF` row.
- **Action:** the first action states what will happen before it happens.
- **Craft:** focus ring, contrast, reading order, and loading/error/success states all verified (see `AI-CREATIVE-QA`).

## Deliberately excluded

Testimonials, logo wall, user counts (none exist yet) · autoplay video with sound · a hero stat presented as proof · any second primary CTA competing with "Try the sample."
