# LANDING-PAGE-BRIEF.md

> Worked example — the fictional product "Relay" from THE $1M DESIGN SYSTEM. Use it as a reference for how a completed file reads. Your own version lives in `../starters/LANDING-PAGE-BRIEF.md`.

## Page job

Help a solo SaaS founder preparing a feature announcement understand Relay, inspect the output, and try a sample.

## Section order

1. Hero with real before-and-after preview
2. Interactive sample action
3. Launch situation and current editing cost
4. Transcript-edit mechanism
5. Output and fidelity comparison
6. Three outcome-led capabilities
7. File handling and founder accountability
8. Fit and limitations
9. One-off and repeat-use pricing
10. Final sample action

## Mobile priority

The headline, subhead, first frame of the comparison, and sample action must appear before the first major scroll.

The side-by-side comparison becomes a controlled toggle on narrow screens. Essential evidence may not depend on hover.

## Acceptance

- Five-second viewers identify screen-demo editing.
- The product shown is the current interface.
- The sample works without private data.
- No claim lacks evidence or qualification.
- The first action explains what happens.
- Focus, contrast, reading order, loading, error, and success are verified.
