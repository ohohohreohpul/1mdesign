# DESIGN-SYSTEM.md

> Worked example — the fictional product "Relay" from THE $1M DESIGN SYSTEM. Use it as a reference for how a completed file reads. Your own version lives in `../starters/DESIGN-SYSTEM.md`.

## Typography

Display: a direct grotesk with compact headings.
UI/body: a neutral sans optimized for screen readability.
Scale: 14, 16, 20, 28, 44, 72.
Reading width: approximately sixty-five characters.
Labels use sentence case; uppercase is reserved for short technical annotations.

## Color roles

- Canvas: near-black
- Raised surface: dark graphite
- Primary text: warm white
- Muted text: cool gray
- Action: cobalt
- Verified improvement: acid lime
- Processing: amber
- Error: red
- Border: visible against both dark surfaces

Acid lime is never used as broad decoration. It means a verified change or completed result.

## Layout

- Twelve-column desktop grid
- Four-column mobile grid
- Eight-point spacing system
- Narrow reading columns beside larger proof frames
- Section transitions use spacing before decorative backgrounds

## Core components

- file upload with privacy statement
- sample-project selector
- transcript editor
- video preview
- suggested-cut review
- processing progress
- format preview
- proof comparison
- price option
- error and recovery

Every component requires default, focus, loading, success, error, and disabled behavior where applicable.
