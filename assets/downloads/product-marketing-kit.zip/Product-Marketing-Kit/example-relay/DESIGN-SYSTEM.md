# DESIGN-SYSTEM.md

> Worked example — the fictional product "Relay" from THE $1M DESIGN SYSTEM. This is a *completed* design system: real, named, paste-ready decisions. Your own version lives in `../starters/DESIGN-SYSTEM.md`. Copy the level of specificity, not Relay's answers.

Relay is a screen-demo editor. The interface is dark so the buyer's own product footage is the brightest thing on screen. Every token below is a decision, not a placeholder.

---

## 1. Typography

| Role | Family | Fallback | Notes |
|---|---|---|---|
| Display / headings | **Söhne Kräftig** (paid) — or **Inter Tight** (free) | `-apple-system, system-ui, sans-serif` | Compact grotesk. Tight tracking `-0.01em` at ≥28px. |
| UI / body | **Inter** (free) | `system-ui, sans-serif` | `font-feature-settings: "cv05","ss01"` for a cleaner `a`/`g`. |
| Technical / timecodes | **JetBrains Mono** (free) | `ui-monospace, Menlo, monospace` | Only for timecodes, durations, file sizes, keyboard hints. |

**Type scale (px / line-height / usage):**

| Token | Size | LH | Use |
|---|---|---|---|
| `text-xs` | 12 | 16 | timecodes, captions, metadata |
| `text-sm` | 14 | 20 | secondary UI, table cells |
| `text-base` | 16 | 24 | body, controls |
| `text-lg` | 20 | 28 | section leads |
| `text-xl` | 28 | 34 | subheads |
| `text-2xl` | 40 | 44 | page headings |
| `text-hero` | 64 | 64 | hero only, one per page |

Reading column ≤ 65ch. Labels sentence case. UPPERCASE reserved for short technical annotations (e.g. `EXPORT · MP4 1080p`), tracked `+0.06em`.

## 2. Color (OKLCH tokens)

```css
:root {
  --canvas:        oklch(0.16 0.006 265);  /* near-black graphite — app background */
  --surface:       oklch(0.21 0.008 265);  /* raised panels, cards, editor rail */
  --surface-hi:    oklch(0.26 0.010 265);  /* hover / active surface */
  --text:          oklch(0.96 0.004 265);  /* warm white — primary text */
  --text-muted:    oklch(0.70 0.010 265);  /* cool gray — secondary text (4.6:1 on canvas) */
  --border:        oklch(0.32 0.010 265);  /* visible on both --canvas and --surface */
  --action:        oklch(0.58 0.19 258);   /* cobalt — primary action, selected transcript */
  --action-hover:  oklch(0.64 0.19 258);
  --verified:      oklch(0.86 0.20 130);   /* acid lime — a VERIFIED change / completed result only */
  --processing:    oklch(0.80 0.16 75);    /* amber — in-progress, non-final */
  --error:         oklch(0.63 0.22 25);    /* red — error + destructive */
  --focus-ring:    oklch(0.80 0.12 258);   /* 2px ring, 2px offset, on every focusable element */
}
```

**Rules:** Cobalt = "you can act / this is selected." Acid lime is **never decoration** — it marks a verified cut or a completed export and nothing else. Amber never means done. Muted text must clear 4.5:1 on `--canvas`; check any text on `--surface` separately.

## 3. Spacing, grid, radius, elevation

- **Space scale (8pt base, 4 for fine):** 4, 8, 12, 16, 24, 32, 48, 64, 96.
- **Grid:** 12-col desktop / 4-col mobile, 24px gutters, max content width 1200px. Narrow reading column beside a larger proof/preview frame (the footage is the hero, not the copy).
- **Radius:** `--r-sm 6px` (inputs, chips) · `--r-md 10px` (cards, panels) · `--r-lg 16px` (preview frame, modals).
- **Elevation:** flat by default. One shadow token for lifted surfaces: `0 8px 24px -12px oklch(0 0 0 / 0.5)`. Depth comes from surface steps, not heavy shadows.

## 4. Motion

- Durations: `--d-fast 120ms` (hover, focus), `--d-base 200ms` (panels, toggles), `--d-slow 320ms` (route/preview transitions).
- Easing: `cubic-bezier(0.2, 0.8, 0.2, 1)` for enter; `ease-in` for exit.
- Animate `transform`/`opacity`/`clip-path` only. The transcript→clip deletion animates the clip collapsing (scaleY + opacity), never a layout reflow.
- `@media (prefers-reduced-motion: reduce)`: cross-fades replace movement; the preview scrubber never auto-plays.

## 5. Core components — each with every state

Every interactive component defines: **default · hover · focus-visible · active · loading · success · error · disabled.**

- **Upload dropzone** — default shows the deletion/privacy policy inline (not on hover). `loading` = amber progress + byte count. `error` = red border + plain cause ("File over 500MB" / "Format not supported: .mov H.265"). Never accept a file without the policy visible.
- **Sample-project selector** — pre-loaded 47s recording so the buyer reaches first value with no upload and no account.
- **Transcript editor** — selected words use `--action`; deleting a sentence collapses the matching clip (motion §4). `focus-visible` ring on every word-range handle; full keyboard: ⌫ deletes selection, ⌘Z restores.
- **Suggested-cut review** — each suggested pause is amber (proposed) until accepted, then the removed span marks `--verified`. Nothing is cut without an explicit accept.
- **Video preview** — scrubber, before/after toggle, captions overlay. `loading` = skeleton at preview aspect ratio (no layout shift). Controls reachable by keyboard; captions are real text, not burned pixels, until export.
- **Fidelity comparison** — source vs export side-by-side on desktop; a controlled toggle on mobile (never hover-dependent).
- **Processing progress** — amber, states the stage ("Aligning transcript" → "Rendering 1080p"), and can be cancelled.
- **Pricing option** — one-off export vs repeat-use, side by side; the free sample export path is visible before any price.
- **Error & recovery** — every error names the cause and the next step; a failed export preserves the edit so no work is lost.

## 6. Accessibility (non-negotiable)

- Text contrast ≥ 4.5:1 (≥ 3:1 for ≥24px). Focus ring visible on **every** focusable element (`--focus-ring`, 2px, 2px offset).
- Full keyboard path through the core task: sample → edit transcript → preview → export. Comparison and preview never depend on hover or drag alone.
- Reduced-motion honored (§4). Live regions announce processing and export completion.

## 7. Paste-ready starter (hand this to your AI)

> Build using these exact tokens. No unlisted colors, fonts, radii, or font sizes. Dark UI; the user's uploaded footage is the brightest element. Acid lime marks verified/completed only. Every interactive element needs all eight states in §5 and a visible focus ring. Animate transform/opacity/clip-path only and honor prefers-reduced-motion. If a design decision isn't covered here, stop and ask — do not invent one.
