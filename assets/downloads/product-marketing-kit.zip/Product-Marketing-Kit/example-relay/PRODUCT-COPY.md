# PRODUCT-COPY.md

> Worked example — the fictional product "Relay" from THE $1M DESIGN SYSTEM. Use it as a reference for how a completed file reads. Your own version lives in `../starters/PRODUCT-COPY.md`.

## Page argument

**Situation:** The feature is finished. The launch post is waiting. The demo is not.

**Problem:** A rough recording makes a finished product feel unfinished. Traditional editing creates a second project after the build.

**Outcome:** Publish a clear, paced product demo while the feature is still new.

**Mechanism:** Upload the screen recording, edit by deleting transcript text, review suggested pauses, add captions and cursor emphasis, and export the required launch format.

**Proof:** A real forty-seven-second raw recording becomes a twenty-four-second demo. Both files remain available for comparison.

**Objections:** Relay preserves the real interface, provides preview before payment, states file handling beside upload, and clearly limits itself to screen demos.

**Action:** Try the sample recording or upload your own.

## Hero

> **Ship the demo while the feature is still new.**
>
> Turn a rough screen recording into a clean launch video—without opening a timeline.

Primary action: **Try the sample**

Secondary action: **Upload a recording**

Early trust line:

> Your interface stays real. Relay edits the recording, not the product.

## Problem section

> You already finished the hard part.
>
> But the first take wanders. The cursor disappears. The useful moment arrives twenty seconds late. Opening a professional editor means turning the announcement into another production task.
>
> Relay is for the space between working software and the video that makes someone understand it.

## Mechanism

**Record naturally**

Do not restart when you miss a word. Capture the real product once.

**Edit the transcript**

Delete a sentence and the matching clip disappears. Review pauses before applying cuts.

**Publish the useful moment**

Add readable captions, keep the cursor visible, preview each format, and export.

## Fit

> Relay is built for product walkthroughs, feature launches, changelog clips, and short help demos.
>
> It is not designed to generate cinematic footage, synthetic presenters, or a fictional version of your interface.

## Final action

> Your feature already works. Make the first look count.
>
> **Edit the sample recording**
