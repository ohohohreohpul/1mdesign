# Command Library

Every AI command from THE $1M DESIGN SYSTEM, collected in one place and grouped by the six decisions. These commands work only when they operate inside decisions — load the relevant kit files (see `CONTEXT-HEADER.md`) before running one.

Paste a command, attach the files it names, and read its output as a draft to judge, not an answer to accept. Commands drawn from the Field Guide's AI Command Library are marked *(Field Guide)*; commands lifted from a chapter are marked with the chapter.

---

## 1. Diagnose — find where the sale breaks

### Find the gap *(Field Guide / Ch. 2)*

> Review the supplied buyer path, copy, product screens, analytics, and interviews. Map evidence to attention, comprehension, relevance, trust, action, and experienced value. Separate observation, participant statement, and inference. Identify the earliest weak threshold and three competing explanations. Do not redesign or recommend features until the diagnosis is explicit.

### Analyze a comprehension test *(Ch. 1)*

> You are analyzing a five-second comprehension test for a product page. Separate direct observation from interpretation. First, tabulate the category, audience, problem, outcome, mechanism, and next action each participant inferred. Quote their exact words. Then identify repeated interpretations, contradictions, and information nobody recovered. Do not recommend copy until the evidence table is complete. Finally, propose three competing explanations for the largest comprehension failure and specify the smallest test that could distinguish them.

### Challenge a feature *(Ch. 3)*

> Evaluate this proposed feature against the supplied positioning, buyer evidence, activation path, and current product behavior. Do not brainstorm implementation. Identify which observed buyer problem it addresses, whether that problem blocks first value or expands scope, what new claims and interface complexity the feature creates, and what cheaper test could validate demand. Argue both for and against building it. Label every unsupported inference.

---

## 2. Position — choose the reason to buy

### Find the buyer's live moment *(Field Guide / Ch. 4)*

> Extract specific situations in which the problem becomes active. For each, record trigger, current behavior, cost, desired progress, frequency, urgency, alternative, and supporting quotation. Reject segments defined only by demographics or broad roles.

### Compare customer entry points *(Ch. 4)*

> Using only the supplied evidence, describe four distinct customer entry points. Each must contain a person, live situation, trigger, current alternative, cost, desired progress, reachable context, and supporting quotations. Do not merge them. Score evidence quality separately from market attractiveness. State what evidence is missing and what would make each entry point a bad choice.

### Position the product *(Field Guide / Ch. 5)*

> Create five positioning options using the approved buyer evidence. Each must specify buyer, live situation, category or frame, progress, current alternative, difference, and reason to believe. Make the options strategically different. Run competitor-substitution and one-breath tests. Do not invent proof.

---

## 3. Copy — make the product obvious

### Translate features *(Field Guide / Ch. 6)*

> For each product feature, map technical capability to enabled behavior, immediate result, meaningful consequence, buyer situation, and required proof. Rank by proximity to first value. Flag features that do not support the chosen position.

### Build the page argument *(Field Guide / Ch. 6)*

> Organize the evidence into situation, problem, outcome, mechanism, proof, objections, and action. Show gaps before writing prose. Ensure every promise has a mechanism and every material claim has evidence or qualification.

### Write without startup costume *(Ch. 6)*

> Draft landing-page copy from the supplied positioning, evidence, feature hierarchy, and page brief. Use concrete nouns and verbs. Do not use "revolutionize," "unlock," "seamless," "supercharge," "game-changing," "next-generation," "effortless," or "AI-powered" unless the phrase communicates indispensable factual information. Do not invent customers, numbers, security claims, integrations, or outcomes. For every section, add an internal note naming the buyer question it answers and the evidence it relies on. Preserve uncertainty where proof is incomplete.

### Critique copy *(Field Guide / Ch. 6)*

> Identify category ambiguity, abstract benefits, inflated consequences, missing mechanisms, unsupported claims, feature parity, vague actions, and generic AI/startup language. Quote the exact text. Explain the buyer question left unanswered. Do not rewrite until the critique is complete.

### Challenge the page *(Ch. 6)*

> Act as a skeptical member of the defined audience. Do not rewrite yet. For every section, identify the buyer question it answers, the claim it introduces, the evidence supplied, and the new uncertainty it may create. Flag generic language, category ambiguity, inflated consequences, and CTAs whose next step is unclear. Quote the exact text behind every criticism.

---

## 4. Design — give the product a direction

### Create creative directions *(Field Guide / Ch. 7)*

> Develop three creative worlds from the same approved position. Each must create a different intended belief, not merely a different style. Define central frame, emotional register, category cues, visual grammar, type, color behavior, composition, imagery, motion, copy behavior, proof behavior, five rules, five exclusions, and risk of misreading.

### Analyze references *(Field Guide / Ch. 8)*

> Examine the references as systems. Separate observable hierarchy, grid, typography, spacing, color roles, components, imagery, and motion from inferred strategy. Identify decisions that support our direction, decisions that conflict, and surfaces that would create imitation.

### Extract a reference system *(Ch. 8)*

> Analyze the supplied reference screenshot as a design system, not as an aesthetic. Describe hierarchy, grid, reading width, type roles, spacing rhythm, color roles, component anatomy, imagery logic, interaction assumptions, and likely responsive behavior. Separate observable properties from inference. Then state which decisions could serve our creative direction, which would conflict with it, and which would create imitation risk. Do not generate code.

### Build a minimal design system *(Field Guide / Ch. 8)*

> Define only the tokens and components required by the current product and page. Use semantic names. Include typography, color roles, spacing, grid, borders, radius, shadow, motion, breakpoints, interaction states, accessibility, and component usage rules. Do not create unused variants.

### Convert decisions into tokens *(Ch. 8)*

> Convert the approved design decisions into a minimal semantic token system. Use role-based names rather than appearance-based names. Define typography, spacing, color, radius, border, shadow, motion, and breakpoint tokens only where required by the supplied components. Explain the job of each token. Do not introduce decorative values that are not supported by the creative direction.

### Inventory the page *(Field Guide / Ch. 9)*

> List every commercial, copy, proof, design, and product element required to make the intended decision possible. Mark each ready, missing evidence, missing decision, or unnecessary. Do not propose layout until the inputs are resolved.

### Architect the page *(Field Guide / Ch. 9)*

> Produce three section sequences representing different argument strategies. For each section state the buyer question, content, evidence, action, and reason for placement. Reject sections included only because SaaS templates commonly contain them.

### Create page architectures, not pages *(Ch. 9)*

> Propose three landing-page architectures from the supplied positioning, page argument, element inventory, proof, and customer state. Each architecture must represent a different argument strategy, not a different visual style. For every section, state the customer question answered, required content, evidence, and reason for its position. Do not write final copy, select colors, or generate code. Flag any section that depends on missing evidence.

### Prepare a coding task *(Field Guide / Ch. 13)*

> Read all project files. List fixed decisions, allowed variation, missing inputs, acceptance criteria, and conflicts before coding. Implement with semantic tokens and approved components. Do not invent marketing content or proof. Include responsive behavior, accessibility, and all required states. Audit after implementation.

### Brief the coding agent *(Ch. 9)*

> Build only from the approved page architecture, copy, creative direction, design system, and component inventory. Treat all claims and proof as fixed. Use semantic tokens and defined components; do not add unapproved colors, gradients, badges, logo strips, testimonials, statistics, sections, or marketing language. Implement mobile first, including focus, loading, empty, error, success, and disabled states. Before coding, list conflicts or missing assets. After coding, audit the result against the acceptance criteria and report deviations.

### Create a production brief *(Ch. 13)*

> Using the approved system files, create a production brief for [asset]. Include its single job, audience state, required message, source assets, composition, product-truth constraints, design tokens, output formats, allowed variation, prohibited choices, proof requirement, accessibility, rights, and acceptance criteria. Do not generate the asset. Identify missing inputs first.

---

## 5. Prove — earn trust without traction

### Build trust *(Field Guide / Ch. 10)*

> Identify the reasonable doubts created by the product type, maturity, action, data, price, and claims. Pair each with observable evidence. Prioritize product, operational, founder, and external proof available without fabricated maturity.

### Build an honest trust plan *(Ch. 10)*

> Using the product type, buyer, action requested, data involved, price, maturity, and available evidence, identify the ten most reasonable trust questions. Rank them by likely impact and moment in the journey. For each, propose an observable answer that does not require customer logos or invented authority. Distinguish product proof, operational proof, founder proof, customer proof, and external proof. Flag claims requiring legal, security, or technical verification.

### Design the demonstration *(Field Guide / Ch. 11)*

> Show a real starting condition, key action, mechanism, result, and meaningful consequence. State what every shot proves, what it cannot prove, required source assets, fidelity risks, disclosures, and reproduction conditions.

### Storyboard the proof *(Ch. 11)*

> Create three demonstration storyboards for the supplied claim and buyer doubt. Each must show a real input, the product's visible mechanism, the output, and the meaningful consequence. Do not use abstract AI imagery or invented customer results. For every shot, state what it proves, what source asset is required, and what could accidentally mislead the viewer. End with a disclosure and verification checklist.

### Inspect fidelity *(Ch. 11)*

> Compare the candidate asset with the supplied product truth sheet and references. Inspect shape, scale, color, material, labels, logos, interface, components, connections, and use context. List discrepancies by severity. Distinguish cosmetic artifacts from changes that misrepresent the product. Do not approve the asset merely because it is polished.

---

## 6. Align — make everything agree

### Audit the product path *(Field Guide / Ch. 12)*

> Compare promise and behavior across discovery, hero, demonstration, sign-up, empty state, core action, processing, result, payment, confirmation, and support. Identify the earliest contradiction in terminology, expectation, proof, interaction, visual direction, or value.

### Write first-use copy *(Ch. 12)*

> Write the first-use sequence from the approved positioning and actual product behavior. For every step, state the user's likely expectation, required instruction, trust concern, progress signal, and recovery path. Use literal labels. Do not introduce capabilities or outcomes absent from the product. Include empty, loading, success, warning, error, cancellation, and support copy.

### Review generated media *(Field Guide / Ch. 13)*

> Compare the output with the creative direction, product truth sheet, source assets, and proof requirements. Inspect fidelity, artifacts, text, materials, scale, brand behavior, accessibility, rights, and misleading implications. Reject strategically wrong output even when aesthetically polished.

---

## 7. Learn — turn behavior into evidence

### Learn from the result *(Field Guide / Ch. 14)*

> Report raw behavior by threshold and segment. Compare with the prior hypothesis. Separate observation from explanation. Identify confounds and missing data. Recommend the smallest next decision, what remains fixed, and what evidence would reverse the conclusion.

### Analyze without false certainty *(Ch. 14)*

> Analyze this test using the stated hypothesis, audience, period, sample, variants, and downstream metrics. Report raw counts before percentages. Identify data-quality problems, confounds, novelty effects, and segment differences. Separate what happened from why it may have happened. Do not call a winner when evidence is insufficient. Recommend the next decision and the smallest follow-up test.
