# Design Treasures — start here

The full `RESOURCE-DIRECTORY.md` lists everything. This is the short version: the highest-leverage, web-verified resources for making an AI-built product look and read top-tier *fast*. If you only open a handful of tabs, open these.

The rule from the book still holds: these give you parts and evidence, not a finished product. Borrow the system, own the components, restyle to your tokens, and put a human approval gate at the end of every AI pipeline. Confirm each license and commercial-use term before you ship. Every URL here was verified live; verify again before you depend on it.

Each entry: **what it is · why it earns the spot · how to actually use it with your AI.**

---

1. **shadcn/ui** — https://ui.shadcn.com
   Copy-into-your-repo React components on accessible primitives + Tailwind.
   *Why:* the base layer nearly every AI coder already emits, and the standard the rest of this list plugs into. Start here and everything else composes.
   *With your AI:* tell your coding agent to build "using shadcn/ui components and CSS-variable tokens only — no unapproved colors or one-off styles." It gives the model a fixed vocabulary so output stays consistent.

2. **shadcn theming + Radix Colors** — https://ui.shadcn.com/docs/theming · https://www.radix-ui.com/colors
   Semantic CSS-variable tokens (OKLCH) plus accessible 12-step light/dark color scales.
   *Why:* one honest, accessible palette beats a model "making it modern." Change a handful of variables and the whole product reskins.
   *With your AI:* have the model map your brand into semantic roles (background, foreground, primary, muted, destructive) using Radix scales, then feed those variables back as fixed tokens for every screen.

3. **Tailwind Plus** — https://tailwindcss.com/plus
   Paid, professionally composed marketing and app sections from the Tailwind team (formerly Tailwind UI).
   *Why:* the fastest way to skip amateur-hour layout; the compositions are what most AI output is unconsciously imitating anyway, done right.
   *With your AI:* pick a section, paste the markup, and ask the model to adapt copy and swap in your tokens — not to redesign it.

4. **21st.dev** — https://21st.dev
   Searchable marketplace of shadcn-based community components and blocks, with MCP support.
   *Why:* when you need a specific part (pricing table, bento grid, testimonial wall), it is faster to find and install a good one than to prompt from zero.
   *With your AI:* install via the shadcn CLI, then have your agent restyle it to your tokens so it stops looking like a stock block.

5. **Aceternity UI + Magic UI** — https://ui.aceternity.com · https://magicui.design
   Ready-made animated components (beams, 3D cards, marquees, hero effects) on React + Motion.
   *Why:* premium motion is where AI-built pages usually fall flat; these give it to you without hand-writing choreography.
   *With your AI:* drop one signature effect into the hero and leave the rest calm. Ask the model to wire it in, then delete anything that distracts from the buyer's decision.

6. **Tremor** — https://tremor.so
   Free, open-source dashboard and chart components that match the shadcn aesthetic.
   *Why:* if your product has a dashboard, this is the difference between "looks designed" and "looks like a default chart library."
   *With your AI:* have the agent build your analytics views from Tremor primitives instead of raw chart code, using the same tokens as the rest of the app.

7. **Motion** — https://motion.dev
   High-performance animation for React and vanilla JS (the independent successor to Framer Motion).
   *Why:* the standard motion engine the good component libraries already use; learn it once and micro-interactions stop feeling generated.
   *With your AI:* ask for animations built on `motion/react` with restrained durations and easing — motion that clarifies flow, not decoration.

8. **Fontshare + one pairing** — https://www.fontshare.com
   Free, distinctive, commercially usable typefaces (serif, sans, display, variable).
   *Why:* typography is the cheapest way to escape the default-template look, and most AI output ships with lazy system fonts.
   *With your AI:* choose two families deliberately (one display, one text), then tell the model to use only those with a real type scale — no ad-hoc font sizes.

9. **Lucide** — https://lucide.dev
   Clean, MIT-licensed icon set (~1,700 icons) with framework packages.
   *Why:* one consistent icon system reads as "designed"; mixed icon styles read as "assembled."
   *With your AI:* standardize on Lucide and forbid the model from mixing in other icon sets or emoji.

10. **Mobbin** — https://mobbin.com
    Curated library of real, shipped app screens and flows, searchable by pattern.
    *Why:* references should be evidence from products that actually ship, not concept art. This is the strongest source of real patterns.
    *With your AI:* find how three real products solve your exact screen, extract the *decisions* (hierarchy, grid, proof placement), and brief those into the model — never "copy this look."

11. **Refero** — https://refero.design
    125,000+ screenshots from 400+ real live web and iOS products, with flows.
    *Why:* a deeper, explicitly real-product complement to Mobbin for landing pages and onboarding.
    *With your AI:* pull references for a specific moment (empty state, pricing, first-run) and use the book's "extract a reference system" command to turn them into a brief.

12. **v0** — https://v0.app
    Vercel's prompt-to-React/Next/Tailwind/shadcn builder.
    *Why:* it emits the exact stack this list is built around, so its output drops straight into a shadcn codebase.
    *With your AI:* feed it your approved page architecture, copy, and tokens — not a vibe. Treat the result as a draft to judge against your acceptance criteria, then finish in Cursor or Claude Code.

13. **Recraft + Ideogram** — https://www.recraft.ai · https://ideogram.ai
    Brand-consistent vector/icon generation (Recraft) and legible in-image text (Ideogram).
    *Why:* the two image jobs generic models fail at — scalable on-brand assets and any graphic containing words.
    *With your AI:* Recraft for logos, spot illustration, and icons; Ideogram for anything with text. Check every output against your product truth sheet before it ships.

14. **Screen Studio** — https://screen.studio
    macOS screen recorder with automatic zoom and smooth cursor motion.
    *Why:* your product actually working is usually your strongest proof asset, and this makes a raw capture look intentional in one pass.
    *With your AI:* script the demo from the book's "design the demonstration" command first — real input, visible mechanism, real result — then record it, no invented data.

15. **PostHog (or Plausible + Microsoft Clarity)** — https://posthog.com · https://plausible.io · https://clarity.microsoft.com
    Product analytics with funnels and session replay (PostHog), or lightweight privacy-first traffic (Plausible) plus free heatmaps and recordings (Clarity).
    *Why:* every decision in this book ends in behavior. Without measurement you are back to guessing.
    *With your AI:* instrument the thresholds from Chapter 14, then feed raw counts (not vibes) into the "analyze without false certainty" command to decide the next smallest test.

---

**One caution worth repeating:** these tools make it trivial to produce output that is polished and untrue — a drifted logo, an invented number, a screen that shows a capability you do not have. Every treasure on this list is a way to move faster toward a product that is *actually* good, not a shortcut around being honest. Keep the human approval gate.
