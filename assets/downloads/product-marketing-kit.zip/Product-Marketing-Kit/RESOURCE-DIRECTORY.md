# Resource Directory

The book's resource directory, collected from Part 8's Field Guide and Chapter 13's tooling notes, then verified against the live web.

Tools change faster than judgment. The chapters teach the decisions; this directory points to where the raw material lives. **Treat every entry as a starting point, not an endorsement. Before you build anything commercial, confirm the license, the commercial-use terms, and how each service handles the files you upload.** Names, owners, and pricing move; every URL here was checked, but check again before you commit.

Read this directory the way the book asks you to read a reference: study the decision it lets you make, not the surface it lets you copy.

Every entry follows one shape: **name — what it is + when to reach for it — URL.**

---

## Where the design system actually comes from

You do not invent a design system from an adjective. You borrow a coherent, battle-tested one and make it yours. Start from a real token and component source rather than asking a model to "make it modern."

### The base layer: components you own

- **shadcn/ui** — copy-into-your-repo React components built on accessible primitives and Tailwind; the de-facto base layer most AI coders already emit and the registry standard everything below plugs into — https://ui.shadcn.com
- **Radix UI (primitives)** — unstyled, accessible React primitives (menus, dialogs, tabs, popovers) with keyboard and focus logic already solved; now maintained by WorkOS and consolidated into a single `radix-ui` package — https://www.radix-ui.com/primitives
- **Base UI** — unstyled, accessible React primitives from the people behind Radix, Floating UI, and MUI; reached stable v1.0 in late 2025 and is increasingly the default headless layer for greenfield builds — https://base-ui.com
- **Tailwind CSS** — the utility-first CSS framework almost every AI-generated UI is built on; v4 ships OKLCH color by default and is what the rest of this section themes on top of — https://tailwindcss.com
- **Tailwind Plus** — the paid, framework-agnostic library of professionally composed sections and templates from the Tailwind team (renamed from "Tailwind UI" in 2025); reach for it to skip building marketing/app blocks from scratch — https://tailwindcss.com/plus

### Component registries and "design treasures"

Copy-paste or CLI-install component collections that ride on shadcn/Tailwind. Use them for polish you would otherwise hand-code — hero sections, animated backgrounds, dashboards — but restyle to your tokens so your product does not look like everyone else's.

- **21st.dev** — searchable community marketplace of shadcn-based components, blocks, and hooks (with an AI generator and MCP); reach for it when you want a large pool of installable parts for an AI-built app — https://21st.dev
- **Awesome shadcn/ui** — community-curated master index of shadcn components, registries, tools, and templates; the discovery list when you need to find a specific block or extension — https://github.com/birobirobiro/awesome-shadcn-ui
- **shadcn/ui Registry Directory** — the official, CLI-aware index of community registries; the "start from the source" version of the awesome-list — https://ui.shadcn.com/docs/directory
- **Aceternity UI** — React/Next components heavy on flashy motion (3D cards, beams, particle backgrounds); reach for it when a landing page needs to look premium and animated without hand-writing the motion — https://ui.aceternity.com
- **Magic UI** — 150+ free animated components (beams, marquees, retro grids) built as a companion to shadcn/ui; reach for it for marketing-page micro-interactions and hero flourishes — https://magicui.design
- **Cult UI** — shadcn-compatible components and full landing blocks with sophisticated built-in animation; reach for it when you want higher-polish sections that still drop into a shadcn project — https://www.cult-ui.com
- **Motion-Primitives** — composable animated primitives (transitions, scroll effects, text/number animations) built on Motion + Tailwind; reach for it when you want reusable motion building blocks rather than whole sections — https://motion-primitives.com
- **HyperUI** — 200+ MIT-licensed, copy-paste plain-Tailwind HTML components (marketing, application, e-commerce); reach for it when you want framework-agnostic markup with zero dependencies — https://www.hyperui.dev
- **Origin UI** — large MIT-licensed set of copy-paste Tailwind v4 + React components following shadcn conventions; reach for it when you need many polished form/input/app-surface variants beyond shadcn's core — https://originui.com
- **Park UI** — accessible components built on headless Ark UI + Panda CSS (and Tailwind) that work across React, Vue, and Solid; reach for it when you want a framework-agnostic system with first-class theming — https://park-ui.com
- **Tremor** — 35+ dashboard and chart components (charts, KPI cards, tables) that match the shadcn aesthetic, now fully free and open-source under Vercel; reach for it when your product needs an analytics dashboard out of the box — https://tremor.so
- **React Bits** — 100+ animated, interactive React components (text effects, animated backgrounds); reach for it when you want eye-catching flourishes for a memorable site — https://reactbits.dev
- **Kokonut UI** — 100+ animated, accessible components built on React + Tailwind + Motion with an opinionated, on-trend look; reach for it when you want animated components that feel less generic — https://kokonutui.com
- **shadcnblocks** — large library of shadcn/ui marketing and app blocks (mostly paid); reach for it when you want ready-made full sections rather than single components — https://www.shadcnblocks.com

*Registries change hands and rename often. Origin UI, for example, may migrate branding ("coss ui") — originui.com still resolves today, but verify before you depend on it. Treat each of these as a source of parts to own and restyle, not a finished look.*

### Complete design languages

- **Vercel Geist** — Vercel's full design system plus the open-source Geist Sans/Mono typefaces; the go-to for a polished, "dev-tool native" look without designing tokens yourself — https://vercel.com/geist
- **Untitled UI** — very large Figma UI kit paired with a React component library; use it to design and ship a coherent product UI fast in a Figma-to-code workflow — https://www.untitledui.com
- **Material 3 (Material Design 3)** — Google's open-source design system with dynamic/tonal color and a token-driven theming model; the choice for Android or a systematic color model — https://m3.material.io

### Color and tokens

- **Radix Colors** — perceptually balanced 12-step light/dark scales with alpha and P3 variants, mapped to semantic roles; use it for accessible palettes instead of hand-picked hex — https://www.radix-ui.com/colors
- **shadcn theming** — shadcn/ui's CSS-variable approach (semantic OKLCH tokens for light/dark); the canonical way an AI-generated shadcn app swaps its whole look by editing a handful of variables — https://ui.shadcn.com/docs/theming
- **OKLCH Color Picker & Converter (Evil Martians)** — interactive picker/converter for the perceptually uniform OKLCH space with P3 gamut and contrast guidance; use it when authoring modern CSS `oklch()` colors — https://oklch.com
- **Realtime Colors** — live tool that previews a color + font palette on a real mock UI; use it to feel a palette in context before committing — https://www.realtimecolors.com
- **Coolors** — fast palette generator and explorer with export; use it for quick brainstorming from scratch — https://coolors.co

### Type

- **Fontshare** — free, high-quality typefaces (serif, sans, display, mono, variable) from the Indian Type Foundry, no attribution required; use it for distinctive type beyond the default look — https://www.fontshare.com
- **Google Fonts** — the largest free, open-source web-font library with easy embedding and self-hosting; the license-safe default — https://fonts.google.com
- **Fontsource** — 2,000+ open-source families packaged as versioned npm packages for self-hosting; use it for privacy, version-locking, and performance (no third-party CDN request) — https://fontsource.org
- **Premium foundries (paid)** — when you want a high-craft, custom feel and can license it: **Klim Type Foundry** (https://klim.co.nz) and **Grilli Type / GT** (https://www.grillitype.com). Two families is usually enough; buy the license before shipping.

### Icons

- **Lucide** — MIT-licensed ~1,700-icon toolkit (a maintained Feather fork) with framework packages; the clean, consistent default — https://lucide.dev
- **Phosphor Icons** — MIT-licensed family with multiple weights (thin to fill); reach for it when you need weight variety and a distinctive look — https://phosphoricons.com
- **Heroicons** — hand-crafted MIT-licensed set from the Tailwind team; reach for it when pairing icons with a Tailwind UI — https://heroicons.com
- **Radix Icons** — crisp 15×15 MIT-licensed icons as React components; reach for it for compact, uniform UI iconography, especially with Radix — https://www.radix-ui.com/icons
- **Tabler Icons** — 1,280+ free MIT-licensed icons on a consistent stroke grid; reach for it when you want a large, cohesive outline set — https://tabler.io/icons

### Motion

- **Motion** — high-performance animation library for React and vanilla JS; the independent successor to Framer Motion (package is now `motion`, import `motion/react`), for declarative UI animation — https://motion.dev
- **GSAP** — battle-tested, framework-agnostic library for complex timeline and scroll motion; now 100% free including all former Club plugins (ScrollTrigger, SplitText, MorphSVG) after the Webflow acquisition — https://gsap.com
- **Lenis** — lightweight smooth-scroll library from darkroom.engineering, often paired with GSAP ScrollTrigger; use it to add smooth, normalized scrolling — https://lenis.dev

---

## Where to look before you brief the AI

References are evidence for a decision, not permission to imitate. Collect systems, then extract hierarchy, grid, type, color roles, and proof behavior. The most useful galleries show **real, shipped products**; treat the aesthetic/concept ones as range, not truth.

### Real shipped products and flows

- **Mobbin** — hand-curated library of real shipped mobile and web app screens and flows, tagged by pattern (freemium) — https://mobbin.com
- **Refero** — 125,000+ screenshots from 400+ real live web and iOS products (explicitly not concept work), with flows and a Figma plugin (freemium) — https://refero.design
- **Screenlane** — daily-updated gallery of real product screenshots organized by UI pattern; free, no signup — https://screenlane.com
- **Page Flows** — annotated screen-recordings of real apps' user journeys across iOS/Android/web (hard paywall after a short trial) — https://pageflows.com
- **Land-book** — daily-curated gallery of thousands of real live landing pages and portfolios, filterable by type and tech stack — https://land-book.com
- **Lapa Ninja** — 7,300+ real shipped landing pages with full-page screenshots and recordings, plus free UI kits — https://www.lapa.ninja
- **SaaS Landing Page** — ~950 real shipped SaaS landing pages (by the Cruip team), filterable by stack, plus templates — https://saaslandingpage.com

### Curated aesthetic direction (mix of shipped and concept)

- **Recent** (formerly Godly) — tight, quality-over-quantity daily feed of real live sites, portfolios, branding, and app UI; the old godly.website now redirects here — https://recent.design
- **Curated.design** — hand-picked gallery of real live websites and patterns, now run under the Craftwork platform — https://curated.design
- **Awwwards** — juried awards showcase of real shipped, live sites judged on design and usability; strong at the experimental end — https://www.awwwards.com
- **Dribbble** — mostly concept and aesthetic "shots," often redesigns that never shipped; useful for visual direction, dangerous if you copy surface over decision — https://dribbble.com

---

## The AI tool stack, by job

Route each task to the tool built for it. The newest model is not automatically the right one; reliability for the job beats novelty. Confirm each tool's data-handling and commercial-use terms before you feed it your product truth.

### Reasoning, positioning, and copy

- **Claude, ChatGPT (GPT), Gemini** — evidence synthesis, positioning options, page arguments, critique, and briefs; this is where the decisions in this book get made — https://claude.ai · https://chatgpt.com · https://gemini.google.com

### Interface generation

- **v0 (Vercel)** — turns prompts into production-ready React/Next/Tailwind/shadcn code, now with a sandbox runtime and GitHub PRs (rebranded from v0.dev) — https://v0.app
- **Lovable** — full-stack "vibe-coding" builder that generates UI, backend, DB, auth, and payments from prompts — https://lovable.dev
- **Bolt** — StackBlitz's in-browser builder that generates and runs a complete full-stack app live in a browser tab — https://bolt.new
- **Cursor** — AI-native code editor (VS Code fork) with agentic editing across your repo; your day-to-day IDE for building the real product — https://cursor.com
- **Claude Code** — Anthropic's agentic CLI that plans, edits, and runs code across a project from the terminal — https://claude.com/claude-code

### Image generation

- **Midjourney** — high-aesthetic text-to-image (and now video) for art direction, atmosphere, and hero imagery — https://www.midjourney.com
- **Ideogram** — the image model that renders legible embedded text; use it for anything containing words (posters, ads, covers) — https://ideogram.ai
- **Recraft** — designer-focused generator with brand-style controls and true vector/SVG output; use it for on-brand icons and scalable assets — https://www.recraft.ai
- **Flux (Black Forest Labs)** — state-of-the-art image models used via API and inside other tools; a controllable engine you can call programmatically — https://bfl.ai
- **Google Imagen** — Google's text-to-image family via Gemini, AI Studio, and Vertex AI, for high-fidelity images in the Google stack — https://deepmind.google/models/imagen/
- **Gemini image models ("Nano Banana")** — "Nano Banana" is Google's nickname for its Gemini-native image models (Nano Banana Pro = Gemini 3 Pro Image), strong at 4K and in-image text; accessed via the Gemini app, AI Studio, and Vertex AI — https://deepmind.google/models/gemini-image/pro/

### Product scenes, motion, and video

- **Higgsfield** — AI video suite built around cinematic camera-motion presets; use it for scroll-stopping social/ad clips with pro camera moves — https://higgsfield.ai
- **Runway** — leading pro AI video platform with editing, VFX, and image-to-video for controllable product footage — https://runwayml.com
- **Kling** — Kuaishou's high-realism, physics-accurate video model with native 4K — https://klingai.com
- **Luma (Dream Machine)** — fast, affordable text/image-to-video for quick motion from stills — https://lumalabs.ai/dream-machine
- **Veo (Google)** — Google DeepMind's flagship video model with strong prompt adherence and native audio — https://deepmind.google/models/veo/
- **Pika** — playful text/image-to-video app for stylized, fun short clips and quick experiments — https://pika.art

### Finishing and fidelity

- **Magnific, Topaz, Krea** — upscaling and enhancement. Treat these as generative steps, not neutral exports: inspect logos, interface text, and edges against your product truth sheet afterward — https://magnific.ai · https://www.topazlabs.com · https://krea.ai

### Model access and orchestration

- **Replicate** — run thousands of open and commercial models via one API, and deploy your own, without managing GPUs — https://replicate.com
- **Fal** — inference platform optimized for fast, low-latency generative media (Flux, video, audio) in production — https://fal.ai
- **OpenRouter** — unified gateway to hundreds of LLMs with fallbacks and cost routing behind one endpoint — https://openrouter.ai
- **MuAPI** — budget generative-media API aggregator giving one key to 100+ media models (a smaller, independent alternative to Replicate/Fal) — https://muapi.ai

### Screen demos and recording

- **Screen Studio** — macOS app that produces polished recordings with automatic zoom and smooth cursor motion; the fastest route to a slick product demo — https://screen.studio
- **Tella** — browser-based screen + camera recorder/editor with layouts and backgrounds for on-brand demos — https://tella.tv
- **Loom** — fast async screen/video messaging with instant shareable links; good for casual walkthroughs and updates — https://www.loom.com
- **Descript** — edits audio/video by transcript, with filler-word removal and overdub; cut demos and clips like editing a doc — https://www.descript.com

Your product actually working is often your strongest proof asset; these are how you capture it.

### Analytics and behavior

- **Plausible** — lightweight, privacy-first, cookieless web analytics (open-source, EU-hosted); simple GDPR-friendly traffic and conversion tracking — https://plausible.io
- **PostHog** — all-in-one product analytics with events, funnels, session replay, feature flags, and A/B tests for in-app behavior — https://posthog.com
- **Microsoft Clarity** — free heatmaps and session recordings; see exactly where visitors drop off on a page — https://clarity.microsoft.com
- **Vercel Analytics** — privacy-friendly traffic plus Web Vitals built into the Vercel platform, zero-config if you deploy there — https://vercel.com/analytics

Use these to measure the thresholds from Chapter 14 instead of guessing.

---

## The one rule that outlives every tool

A multi-tool chain accumulates error. A correct product reference can drift through image generation, video generation, upscaling, and compression until the output is convincing and untrue. Keep a human approval gate and your product truth sheet at the end of every pipeline.

The tools will be different next year. The judgment in this book is the part that keeps.
