# Resource Directory

The book's resource directory, collected from Part 8's Field Guide and Chapter 13's tooling notes.

Tools change faster than judgment. The chapters teach the decisions; this directory points to where the raw material lives. **Treat every entry as a starting point, not an endorsement. Before you build anything commercial, confirm the license, the commercial-use terms, and how each service handles the files you upload.**

Read this directory the way the book asks you to read a reference: study the decision it lets you make, not the surface it lets you copy.

---

## Where the design system actually comes from

You do not invent a design system from an adjective. You borrow a coherent, battle-tested one and make it yours. Start from a real token and component source rather than asking a model to "make it modern."

### Component systems and tokens

- **shadcn/ui** — copy-in React components you own and can restyle; the current default for AI-built product UIs.
- **Radix UI / Base UI** — unstyled, accessible primitives (menus, dialogs, tabs) with keyboard and focus logic already solved.
- **Tailwind CSS + Tailwind UI** — the utility system most AI coders already emit, plus a paid library of professionally composed sections.
- **Vercel Geist, Untitled UI, Origin UI, Park UI** — complete design languages with defined type scales, spacing, and color roles you can adopt wholesale.
- **Radix Colors, Tailwind palette, oklch color tooling** — semantic, accessible color scales instead of hand-picked hex values.

### Type and icons

- **Fontshare, Google Fonts, Fontsource** — real typefaces with clear licenses; two families is usually enough.
- **Lucide, Phosphor, Heroicons, Radix Icons** — consistent icon sets that behave as one system.

---

## Where to look before you brief the AI

References are evidence for a decision, not permission to imitate. Collect systems, then extract hierarchy, grid, type, color roles, and proof behavior.

- **Mobbin** — real product flows and screens, searchable by pattern.
- **Godly, Land-book, Lapa Ninja, SaaS Landing Page** — curated landing pages worth dissecting.
- **Refero, Screenlane, Page Flows** — interaction and onboarding patterns.
- **Awwwards, Dribbble** — useful for range; dangerous if you copy surface over decision.

---

## The AI tool stack, by job

Route each task to the tool built for it. The newest model is not automatically the right one; reliability for the job beats novelty.

### Reasoning, positioning, and copy

- **Claude, GPT, Gemini** — evidence synthesis, positioning options, page arguments, critique, and briefs. This is where the decisions in this book get made.

### Interface generation

- **v0, Lovable, Bolt, Cursor, Claude Code** — turn an approved page brief and design system into working, responsive components.

### Image generation

- **Midjourney** — art direction and atmosphere.
- **Ideogram** — images that must contain legible text.
- **Recraft** — brand-consistent vector and icon work.
- **Google Imagen, Flux (via Freepik/Fal)** — photographic and product-adjacent imagery.

### Product scenes, motion, and video

- **Higgsfield** — cinematic camera motion and controlled product/brand video moments.
- **Runway, Kling, Luma, Veo, Pika** — text- and image-to-video for short demonstrations and motion studies.

### Finishing and fidelity

- **Magnific, Topaz, Krea** — upscaling and enhancement. Treat these as generative steps, not neutral exports: inspect logos, interface text, and edges against your product truth sheet afterward.

### Model access and orchestration

- **Replicate, Fal** — hosted access to many open models with reproducible, API-driven pipelines.
- **MuAPI, OpenRouter** — unified access to multiple models behind one interface.

### Screen demos and recording

- **Screen Studio, Tella, Loom, Descript** — capture and edit the product actually working, which is often your strongest proof asset.

### Analytics and behavior

- **Plausible, PostHog, Microsoft Clarity, Vercel Analytics** — measure the thresholds from Chapter 14 instead of guessing.

---

## The one rule that outlives every tool

A multi-tool chain accumulates error. A correct product reference can drift through image generation, video generation, upscaling, and compression until the output is convincing and untrue. Keep a human approval gate and your product truth sheet at the end of every pipeline.

The tools will be different next year. The judgment in this book is the part that keeps.
