# POSITIONING.md — starter

> Fill this for your own product. Delete every `>` prompt line once the decision is final.
> Keep statements short, specific, and supported by evidence. See `../example-relay/POSITIONING.md` for a completed version.
> Source chapters: 4 (One Buyer, One Painful Moment) and 5 (Position the Outcome, Not the Tool).

## Product

- **Name:** [what is it called?]
- **Recognizable category:** [what shelf does a buyer already file this under?]
- **Factual description:** [one sentence, no adjectives — what does it actually do?]

> Good looks like: a stranger could repeat the category and description back to you correctly.

## Primary buyer

- **Person or role:** [one specific person, not a demographic]
- **Live situation:** [the moment the problem becomes active]
- **Trigger:** [what just happened that makes them look for help now?]
- **Current behavior / workaround:** [what do they do today instead?]
- **Cost, risk, or frustration:** [what does the current behavior cost them?]
- **Desired progress:** [the outcome they are trying to reach]

> Good looks like: one buyer in one situation, described with their words — not "teams" or "creators" in general.

## Position

> Complete the sentence using the fields above. This is the load-bearing line of the whole kit.

For **[buyer in situation]**, **[product]** is the **[category / frame]** that helps them **[progress]**, unlike **[current alternative]**, because **[mechanism / reason to believe]**.

> Good looks like: it passes the one-breath test (readable aloud in one breath) and names a real alternative, not a straw man.

## First value

- **First valuable result:** [the smallest real win the product delivers]
- **Time / effort to reach it:** [how long until they see it?]

> Good looks like: a concrete action a user takes and an immediate, visible result — not a promised long-term benefit.

## Boundaries

- **Best for:** [where this is the right choice]
- **Not designed for:** [what this refuses to be]
- **Claims we cannot make:** [statements without evidence yet]
- **Audiences we are not targeting yet:** [deliberately out of scope]

> Good looks like: positioning is a refusal — you can name what you are giving up.

## Evidence

- **Customer language supporting this position:** [exact quotes]
- **Behavior supporting it:** [what people actually do]
- **What could disprove it:** [the evidence that would make you change this]
