# PRODUCT-COPY.md — starter

> Fill this for your own product. Delete every `>` prompt line once the decision is final.
> Write the hero last. See `../example-relay/PRODUCT-COPY.md` for a completed version.
> Source chapter: 6 (Copy That Makes the Product Obvious).

## Page argument

> State the argument before writing any prose. Every promise needs a mechanism; every material claim needs evidence.

1. **Situation:** [what is true for the buyer right now?]
2. **Problem:** [why the current situation costs them]
3. **Outcome:** [the result the product makes possible]
4. **Mechanism:** [how the product produces that result]
5. **Proof:** [the evidence that it works]
6. **Objections:** [the honest answers to real doubts]
7. **Action:** [the specific next step]

> Good looks like: the seven lines read as one connected argument, not seven feature blurbs.

## Hero

- **Headline:** [the outcome, in the buyer's words]
- **Subhead:** [the mechanism in one line]
- **Primary CTA:** [the lowest-commitment real next step]
- **Secondary CTA (only if needed):** [an alternative path]
- **Hero proof / demonstration:** [what the buyer sees, not just reads]
- **Early trust line:** [the first honest reassurance]

> Good looks like: a five-second viewer can name the category, the buyer, and the next action.

## Feature hierarchy

| Feature | Behavior enabled | Immediate result | Meaningful consequence | Priority |
|---|---|---|---|---|
| [feature] | [what it lets the buyer do] | [what they see right away] | [why that matters] | [1 = closest to first value] |

> Good looks like: features are ranked by proximity to first value, and each one supports the position.

## Objections

| Objection | Honest answer | Evidence | Best page location |
|---|---|---|---|
| [real doubt] | [truthful response] | [proof or qualification] | [where it belongs] |

## Voice

- **Sound like:** [the register — e.g. a precise colleague]
- **Sentence behavior:** [short and declarative? technical?]
- **Vocabulary to use:** [concrete verbs and nouns]
- **Vocabulary to avoid:** [banned words — e.g. revolutionize, unlock, seamless, supercharge, effortless]
- **Tone under error / stress:** [how error copy should read]

## Claims

- **Approved claims:** [statements you can support]
- **Claims requiring qualification:** [true only under stated conditions]
- **Prohibited or unsupported claims:** [do not write these]

## CTA logic

- **Visitor state:** [what they know and feel at this point]
- **Appropriate next action:** [what the button offers]
- **Commitment required:** [account? payment? nothing?]
- **What happens immediately afterward:** [the honest next screen]

> Good looks like: the CTA describes what actually happens next — no surprise sign-up wall.
