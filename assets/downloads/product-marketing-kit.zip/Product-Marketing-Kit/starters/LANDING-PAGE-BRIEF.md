# LANDING-PAGE-BRIEF.md — starter

> Fill this for your own product. Delete every `>` prompt line once the decision is final.
> The page is finished when the decision is possible — not when it looks done. See `../example-relay/LANDING-PAGE-BRIEF.md` for a completed version.
> Source chapters: 9 (Build the Elements Before the Page) and 12 (Make the Whole Product Tell the Same Story).

## Page job

- **Primary audience state on arrival:** [what they know and feel when they land]
- **One decision this page must enable:** [the single choice]
- **Primary CTA:** [the action that decision produces]
- **Conversion definition:** [what counts as success]

> Good looks like: one page, one decision — not a tour of every feature.

## Required elements

> Mark each: ready / missing evidence / missing decision / unnecessary.

- Positioning: [status]
- Page argument: [status]
- Product demonstration: [status]
- Proof: [status]
- Price / offer: [status]
- Objections: [status]
- Founder / trust: [status]
- Policies (file handling, security, terms): [status]

## Section sequence

| Order | Section | Buyer question answered | Required content | Required evidence |
|---|---|---|---|---|
| 1 | Hero | [question] | [content] | [evidence] |
| 2 | | | | |
| 3 | | | | |

> Good looks like: every section answers a real buyer question — no section exists because a template usually has one.

## Mobile priority

- **Visible before the first scroll:** [headline, subhead, first proof frame, primary action]
- **Primary action behavior:** [how the CTA works on narrow screens]
- **Demonstration behavior:** [hover interactions become taps/toggles]
- **Elements removed or simplified:** [what is cut on mobile]

> Good looks like: essential evidence never depends on hover.

## Fixed decisions

> These come from the other files and must not be re-litigated during build.

- Positioning: [reference POSITIONING.md]
- Copy: [reference PRODUCT-COPY.md]
- Direction: [reference CREATIVE-DIRECTION.md]
- Design tokens: [reference DESIGN-SYSTEM.md]
- Proof: [reference PRODUCT-PROOF.md]

## Allowed variation

- Layout concepts: [what the builder may explore]
- Component composition: [freedom within the system]
- Motion: [permitted movement]
- Supporting copy: [minor wording]

## Negative criteria

- No fake logos or testimonials.
- No unsupported superlatives.
- No generic "AI-powered" headline.
- No decorative section without a buyer question.
- No abstract hero replacing product proof.
- No new colors, typefaces, or components outside the system.

## Acceptance criteria

- A new visitor can explain the product after five seconds.
- The page identifies a specific buyer situation.
- The core task is demonstrated, not just described.
- Every major claim has evidence or qualification.
- The mobile path is complete.
- Keyboard, contrast, reading order, and focus states are checked.
