# CREATIVE-DIRECTION.md — starter

> Fill this for your own product. Delete every `>` prompt line once the decision is final.
> Direction is a belief, not a style. See `../example-relay/CREATIVE-DIRECTION.md` for a completed version.
> Source chapters: 7 (Your Product Needs a World) and 8 (Learn Enough Design to Direct AI).

## Direction

> One sentence that ties feeling, frame, evidence, and expression together.

Make **[buyer]** feel **[intended state]** by presenting **[product]** as **[frame]**, proven through **[evidence]**, and expressed with **[distinctive behavior]**.

> Good looks like: the sentence would produce a different page than a generic competitor's, and it names how belief is proven — not just how it looks.

## Intended belief

- **What the buyer should believe after seeing it:** [one honest belief]
- **Intended feeling:** [the emotional register]

## World

- **Central idea / metaphor:** [the organizing concept]
- **Category cues to retain:** [signals that keep you recognizable]
- **Convention to challenge:** [the tired default you refuse]
- **Visual grammar:** [how surfaces, marks, and layout behave]
- **Typography behavior:** [how type sets pace and hierarchy]
- **Color behavior:** [what each color is allowed to mean]
- **Composition:** [how space and proof are arranged]
- **Imagery logic:** [real frames? subjects? what is shown]
- **Motion behavior:** [what movement is allowed to do]
- **Language behavior:** [how copy sounds in this world]
- **Proof behavior:** [how evidence is presented]

> Good looks like: distinct without being strange — every choice is a consequence of the intended belief.

## Rules

> Five positive commitments the work must honor.

1. [rule]
2. [rule]
3. [rule]
4. [rule]
5. [rule]

## Exclusions

> Five clichés or choices the work must never contain (name the specific ones your category overuses).

1. [exclusion]
2. [exclusion]
3. [exclusion]
4. [exclusion]
5. [exclusion]

## References

> Record the decision being borrowed — not the URL, and never the surface.

| Reference | Relevant decision | Why it fits our direction | What must not be copied |
|---|---|---|---|
| [source] | [the specific decision] | [why it serves the belief] | [the surface to avoid] |

> Good looks like: each reference explains a decision you can reuse, and a line you will not cross.
