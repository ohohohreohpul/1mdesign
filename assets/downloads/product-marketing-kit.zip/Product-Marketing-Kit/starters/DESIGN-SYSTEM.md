# DESIGN-SYSTEM.md — starter

> Fill this for your own product. Delete every `>` prompt line once the decision is final.
> Borrow a coherent, battle-tested system and make it yours — do not invent one from an adjective. See `../RESOURCE-DIRECTORY.md` for real token and component sources, and `../example-relay/DESIGN-SYSTEM.md` for a completed version.
> Source chapters: 8 (Learn Enough Design to Direct AI) and 13 (Give Your AI a Memory).

## Principles

> Two or three rules that govern every visual decision.

1. [principle]
2. [principle]
3. [principle]

## Typography

- **Display family:** [headings]
- **Text / UI family:** [body and interface — two families is usually enough]
- **Type scale:** [the fixed step sizes, e.g. 14 / 16 / 20 / 28 / 44 / 72]
- **Line-height rules:** [how line height changes by role]
- **Reading width:** [max characters per line, ~65 is a safe default]
- **Case rules:** [where sentence case vs. uppercase is used]

## Color roles

> Name colors by job, not appearance. Record accessible foreground/background pairs.

- **Canvas / surface primary:** [value]
- **Raised surface / secondary:** [value]
- **Primary text:** [value]
- **Muted text:** [value]
- **Action:** [value]
- **Proof / info:** [value]
- **Success:** [value]
- **Warning / processing:** [value]
- **Danger / error:** [value]
- **Border:** [value]

> Good looks like: every color has one defined job, and reserved accents are never used as decoration.

## Layout

- **Desktop grid:** [e.g. twelve columns]
- **Mobile grid:** [e.g. four columns]
- **Content width:** [max container width]
- **Spacing scale:** [e.g. eight-point system]
- **Section rhythm:** [how sections are separated]
- **Density:** [how tight or open the interface reads]

## Components

> For each component define purpose, anatomy, variants, responsive behavior, and states. List only components this product and page actually need.

- **Button:** [purpose / variants]
- **Input:**
- **Navigation:**
- **Card:**
- **Proof block:**
- **Comparison:**
- **Pricing:**
- **Dialog / modal:**
- **Toast / notification:**
- **Empty state:**

> Good looks like: no unused variants — the system covers what exists, nothing speculative.

## States

- **Hover:**
- **Focus:** [must be visible]
- **Active:**
- **Loading:**
- **Success:**
- **Error:**
- **Disabled:**

## Accessibility requirements

- **Contrast:** [minimum target]
- **Keyboard path:** [every action reachable]
- **Focus visibility:** [always shown]
- **Reading order:** [logical]
- **Meaning not by color alone:** [confirmed]

## Avoid

- Decorative patterns that conflict with the direction.
- Component libraries not approved here.
- Inaccessible color combinations.
- Generic AI-SaaS defaults (glowing orbs, purple gradients, floating icon grids).
