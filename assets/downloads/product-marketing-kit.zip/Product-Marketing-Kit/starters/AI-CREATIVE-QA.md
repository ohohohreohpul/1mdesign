# AI-CREATIVE-QA.md — starter

> Fill and run this checklist before shipping any AI-generated asset (page, image, video, email, interface).
> Adapt the product-fidelity and brand rows to your own product. See `../example-relay/AI-CREATIVE-QA.md` for a completed version.
> Source chapters: 11 (Show the Product Working) and 13 (Give Your AI a Memory).

> Good looks like: you can reject a polished asset that is strategically wrong — being aesthetically finished is not a pass.

## Strategy

- [ ] Speaks to the correct buyer and situation
- [ ] Carries one primary reason to buy
- [ ] Agrees with the approved positioning
- [ ] Does not introduce a new promise or claim

## Copy

- [ ] Factual statements verified
- [ ] Claims supported or qualified
- [ ] No invented numbers, customers, quotes, or credentials
- [ ] CTA accurately describes the next step
- [ ] No generic filler or prohibited language (revolutionize, unlock, seamless, supercharge, effortless, AI-powered)

## Brand and design

- [ ] Uses approved tokens and components only
- [ ] Hierarchy is clear without decoration
- [ ] References informed decisions rather than being copied
- [ ] Mobile behavior reviewed
- [ ] Loading, error, empty, focus, and disabled states exist
- [ ] Avoids the excluded category clichés listed in `CREATIVE-DIRECTION.md`

## Product fidelity

- [ ] Product shape, label, UI, color, and behavior are accurate
- [ ] Generated visuals do not invent capabilities
- [ ] Screenshots show the current product
- [ ] Demonstrations are reproducible under stated conditions

## Accessibility

- [ ] Contrast checked
- [ ] Keyboard path checked
- [ ] Focus visible
- [ ] Reading order logical
- [ ] Alt text / captions supplied
- [ ] Meaning does not rely on color alone

## Rights and transparency

- [ ] Sources recorded
- [ ] Licenses and permissions recorded
- [ ] People have appropriate releases
- [ ] AI use disclosed where required
- [ ] No confidential material exposed

## Output

- [ ] Dimensions and formats correct
- [ ] Resolution sufficient
- [ ] Text rendered cleanly (inspect after any upscaling step)
- [ ] Links and analytics work
- [ ] Metadata, social preview, and favicon checked
