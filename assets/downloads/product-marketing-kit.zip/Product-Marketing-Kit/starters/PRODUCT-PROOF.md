# PRODUCT-PROOF.md — starter

> Fill this for your own product. Delete every `>` prompt line once the decision is final.
> Replace social proof you do not have with product proof you do. See `../example-relay/PRODUCT-PROOF.md` for a completed version.
> Source chapters: 10 (Trust Without Traction) and 11 (Show the Product Working).

## Claim-to-proof map

> One row per material claim. If a claim has no observable evidence, it is not ready to publish.

| Claim | Buyer doubt | Observable evidence | Format | Source | Permission | Limitation |
|---|---|---|---|---|---|---|
| [claim] | [the honest doubt behind it] | [what the buyer can see] | [demo / comparison / sandbox / policy] | [where it comes from] | [rights secured?] | [what it does not prove] |

> Good looks like: every claim is paired with something the buyer can inspect, and every proof states its limit.

## Core demonstration

- **Starting problem / input:** [the real before-state]
- **Key action:** [what the user does]
- **Mechanism shown:** [how the product works, made visible]
- **Visible result:** [the after-state]
- **Meaningful consequence:** [why the result matters]
- **Conditions:** [the stated conditions the demo runs under]
- **What it proves:** [the specific, honest claim]
- **What it does not prove:** [the boundary — universal results, conversion, etc.]

> Good looks like: a real transition the current product can actually perform, with conditions stated.

## Trust inventory

> Which of these do you honestly have today? Use what is real.

- Real product screenshots: [have / need]
- Sample outputs: [have / need]
- Founder / team identity: [have / need]
- Documentation: [have / need]
- Changelog / status: [have / need]
- Security / privacy information: [have / need]
- Support / contact: [have / need]
- Pricing and terms: [have / need]
- Honest limitations: [have / need]
- Real customer evidence: [have / need — do not fabricate]

## Prohibited proof

- No invented testimonials.
- No fake customer logos.
- No synthetic users presented as real.
- No unmeasured performance numbers.
- No conceptual image presented as product evidence.
