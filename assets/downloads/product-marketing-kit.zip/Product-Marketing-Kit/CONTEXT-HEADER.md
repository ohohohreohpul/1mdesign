# Context Header

The context protocol from Chapter 13, "Give Your AI a Memory." A longer prompt is not project memory. These seven files are. This header is how you point an AI session at them so it stops erasing your decisions between tasks.

---

## Paste this at the top of every production task

> Read `POSITIONING.md`, `PRODUCT-COPY.md`, `CREATIVE-DIRECTION.md`, `DESIGN-SYSTEM.md`, `PRODUCT-PROOF.md`, `LANDING-PAGE-BRIEF.md`, and `AI-CREATIVE-QA.md` before acting. Treat approved positioning, claims, evidence, tokens, components, and exclusions as fixed. If instructions conflict, stop and identify the conflict. If evidence or an asset is missing, request it instead of inventing it. Do not add sections, features, claims, testimonials, logos, numbers, colors, fonts, or components without explicit approval.

The header is not magic; it tells the agent where project truth lives.

---

## The context protocol

**Before asking AI to create:**

1. Load the relevant files.
2. State the exact task.
3. Identify which decisions are fixed.
4. Identify what can vary.
5. Specify output format.
6. Include negative criteria.
7. Define how the output will be judged.

**After selecting:**

1. Record the decision.
2. Update the relevant file.
3. Remove obsolete instructions.
4. Run QA (`AI-CREATIVE-QA.md`) before shipping.

Your files become the memory of the product.

---

## How to load these files into Claude, Cursor, or v0

The mechanism differs by tool, but the goal is the same: make the files readable in the same context as the task.

- **Claude (chat or Claude Code):** attach the completed files from your `starters/` copies (or drop the folder into a Claude Code project) and paste the context header as the first instruction. In Claude Code, keeping the files in the working directory lets the agent read them directly.
- **Cursor:** keep the files in the repository and reference them with `@FILE` mentions (for example `@POSITIONING.md`) so they enter the model's context, then paste the header.
- **v0 / Lovable / Bolt:** paste the relevant files' contents into the prompt alongside the header, since these tools work best from a single brief. `LANDING-PAGE-BRIEF.md`, `DESIGN-SYSTEM.md`, and `PRODUCT-COPY.md` are usually the ones a build tool needs.

Load only the files a task actually needs, but always include the header so fixed decisions stay fixed.

---

## Keep a decision log

Record decisions as you make them. Three weeks later, an agent may propose the same concept you rejected; the record explains why the decision was made and what evidence would justify reopening it.

| Date | Decision | Evidence | Alternatives rejected | Files affected |
|---|---|---|---|---|
| | | | | |

---

## Separate three layers

Never let a production prompt silently alter product truth or strategy.

- **Truth** — capabilities, evidence, rights, constraints, customer language, product references.
- **Decision** — positioning, message hierarchy, creative direction, design system.
- **Production** — the exact page, image, video, email, or interface being created.
