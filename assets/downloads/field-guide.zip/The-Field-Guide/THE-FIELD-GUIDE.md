# THE FIELD GUIDE
### Design & prompt vocabulary for AI-built products

The companion reference to **THE $1M DESIGN SYSTEM** by Jiranan Oh.

The book gives you a *process* — diagnose, position, write, design, prove. This guide gives you the *language* to run it. If you built a real product with AI but can't yet name a camera angle, a copywriting framework, or the difference between glassmorphism and neo-brutalism, this is the missing vocabulary. You don't need to become a designer. You need enough words to direct one — or to direct the AI standing in for one.

**How to use it:** read Section 1 to find a visual direction, Sections 2–3 to brief image/video/copy, Section 4 to choose your foundation, Section 5 to connect it all to your brand, and Section 6 as a quick-reference glossary. Every external link was web-verified on 2026-07-31; tools and trends move, so confirm before you depend on one, and always check licenses and commercial-use terms yourself.

**The one rule that outranks everything here:** these give you parts and vocabulary, not permission to fake. A beautiful asset that misrepresents your product is a liability. Direct the work, then check it against what's true. Keep a human approval gate at the end of every AI pipeline.

---

## Section 1 — Design languages (with real, live examples)

A "design language" is a coherent set of visual decisions with a point of view. Picking one on purpose is the fastest way to stop looking like a default template. Below: what each is, when it fits, and **real sites currently shipping it** (agency/portfolio/tool/publication sites are labeled so you don't mistake them for consumer products). Study the *decisions*, not the pixels — then restyle to your own brand.

### Glassmorphism
Frosted, translucent panels: a background blur, thin light borders, soft shadows, elements that appear to float on tinted glass.
**Use it for:** layered, image-rich or dark surfaces (dashboards, media, OS-style chrome) where you want depth without heavy panels. In 2026 it mostly appears as *accents* (nav bars, floating cards, overlays), not whole pages. Watch contrast and low-end performance.
- **Reflect** — networked note-taking app; dark aurora background with translucent frosted pills and floating glass panels. — https://reflect.app
- **Raycast** — Mac productivity launcher; floating frosted-glass nav over a soft blue backdrop. — https://www.raycast.com
- **Apple "Liquid Glass"** *(reference)* — Apple's 2025 system-wide translucent material (iOS 26 / macOS Tahoe); the highest-profile shipped instance. — https://www.apple.com/newsroom/2025/06/apple-introduces-a-delightful-and-elegant-new-software-design/

### Neo-brutalism
Deliberately raw and loud: thick solid borders, hard offset shadows with *no* blur, flat saturated color blocks, chunky bold type. It rejects soft gradients.
**Use it for:** brand-forward marketing, indie products, creative/food/culture businesses that want personality over corporate polish. Poor fit for calm, trust-heavy, data-dense contexts.
- **Curry Cafe** — a real Melbourne restaurant; thick colored border blocks, marquee bands of shouting uppercase type, raw vertical nav. A genuine shipped business site, not concept art. — https://curry.cafe
- **Neobrutalism Components** *(tool)* — a shadcn/ui-based component library whose own site is fully neo-brutalist; the fastest way to build the look. — https://www.neobrutalism.dev

*(Note: Gumroad and Feastables are often cited here from older lists — both have since moved to softer designs. Don't repeat that claim.)*

### Bento grid
A modular grid of different-sized cards, each holding one feature — like a Japanese bento box. Hierarchy comes from cell size, not extra chrome.
**Use it for:** feature overviews and product landing pages that must present many capabilities at a glance. The default composition of 2025–26 product pages.
- **Apple — iPhone 17 Pro** — the "Get the highlights" section is the canonical bento: tiles of varying size for chip, camera, OS, etc. — https://www.apple.com/iphone-17-pro/
- **Supabase** — developer platform; its "best of breed products, integrated" section is a bento of feature tiles (Database, Auth, Storage, Realtime, Vector…). — https://supabase.com

### Editorial / Swiss typographic
Grid-driven, type-first modernism: restrained sans-serif doing the work, strong hierarchy, left alignment, asymmetric balance, generous whitespace. Content over decoration.
**Use it for:** publications, portfolios, foundries, and brands that want rigor and timeless restraint. Rewards good typography; punishes weak content.
- **Grilli Type** *(foundry)* — textbook International Typographic Style: precise modular grid, left-aligned specimens, lots of white space. — https://www.grillitype.com
- **Kinfolk** *(publication)* — lifestyle magazine; a restrained editorial grid you can learn spacing and hierarchy from. — https://www.kinfolk.com

### Dark luxury / minimal luxury
Deep near-black backgrounds, sparse high-contrast type, large hero imagery, slow restrained motion. Atmosphere over density.
**Use it for:** premium, aspirational brands (auto, fashion, high-end SaaS) where confidence and exclusivity beat information volume.
- **Linear** *(SaaS)* — product-development tool; the reference "quiet luxury" software aesthetic — dark, minimal, precise. — https://linear.app
- **Lamborghini** — automotive; dark luxury with minimal chrome and hero product imagery. — https://www.lamborghini.com/en-en

### Retro-futurism / Y2K
Retro-OS interfaces, neon/beige palettes, pixel and VHS texture, early-web and 90s sci-fi nostalgia rebuilt with modern polish.
**Use it for:** playful, nostalgic, culture-forward brands and one-off experiences. A strong differentiator; usually wrong for serious enterprise.
- **Poolsuite** — internet-radio player with a Windows/Mac-98-style Y2K interface; the canonical reference. — https://poolsuite.net
- **Playdate (by Panic)** — retro handheld console; a warm, nostalgic product site around real shipped hardware. — https://play.date

### Big-type maximalism
Oversized type as the primary visual — bold weights, experimental letterforms, type that fills the screen. Scale and volume as the aesthetic.
**Use it for:** studios, launches, and campaign pages that want immediate impact. Demands strong art direction to avoid becoming noise.
- **MSCHF** — a real brand; a dense numbered directory of 125+ projects, austere type, information overload *as* voice. — https://mschf.com
- **basement.studio** *(agency)* — bold large-type studio site (the team also co-designed Vercel's Geist typeface). — https://basement.studio

### Claymorphism *(handle with care)*
Soft, puffy 3D "clay" shapes, big radii, dual inner shadows. **Honest status:** genuinely niche in 2026 — it lives mostly in edtech/kids' products, Dribbble concepts, and CSS demos. The clearest real, mainstream example is **Duolingo** (pressable rounded buttons, thick colored bottom shadows) — https://www.duolingo.com. If you want this look, treat it as an accent on individual controls, not a whole-site language.

> **How to use this section with your AI:** pick *one* language, then use the book's "extract a reference system" command on two of the real examples above — pull the *decisions* (palette logic, type scale, spacing rhythm, motion) into a brief. Never tell the model "copy this site."

---

## Section 2 — AI image & video vocabulary

You don't need to be a cinematographer. You need the words. Generic prompts ("a nice hero image of my app") produce generic results because the model has nothing to lock onto. This vocabulary is the difference between "make it look good" and directing a shot. Use it in Midjourney, Ideogram, Recraft (image) and Veo, Kling, Higgsfield, Runway (video).

### 2.1 Shot size — how much frame the subject fills
| Term | What it does | Use for |
|---|---|---|
| Extreme wide / establishing | subject small in a large space | context, scale, "where we are" |
| Wide shot | full subject + surroundings | product-in-context, lifestyle |
| Medium shot | subject from ~waist up | people, testimonials, founder shots |
| Close-up | fills frame with one thing | a detail, a texture, one UI element |
| Extreme close-up / macro | a fragment | material, craft, tactility |

### 2.2 Camera angle — where the lens sits
- **Eye-level** — neutral, honest; the default for trust.
- **Low angle** (looking up) — makes the subject powerful, heroic; good for a flagship shot.
- **High angle** (looking down) — makes the subject smaller, or shows arrangement.
- **Overhead / top-down / flat-lay** — schematic, editorial; great for arranging objects or cards.
- **Dutch angle** (tilted horizon) — tension, energy; use sparingly.
- **Three-quarter (¾)** — the standard "product hero" angle for physical objects and device mockups.

### 2.3 Lens & camera specs — the words that force realism
Naming a focal length and aperture is the single biggest upgrade to an AI photo prompt.
| Spec | Effect | When |
|---|---|---|
| 24–35mm (wide) | expansive, slight edge distortion | environments, dynamic scenes |
| 50mm | natural, close to the human eye | honest product/people shots |
| 85mm (portrait) | flattering compression, subject pops | people, founder portraits |
| 100mm macro | extreme detail | textures, materials, craft |
| f/1.4–f/2.8 (wide aperture) | shallow depth of field, creamy **bokeh** | isolate the subject |
| f/8–f/16 (narrow aperture) | everything sharp, deep focus | flat-lays, product-line shots |

Add `shot on 35mm film` or `shot on Hasselblad` to bias toward a photographic look.

### 2.4 Lighting — the mood dial
- **Soft / diffused (softbox)** — flattering, premium, clean. Safe default for product & SaaS.
- **Hard light** — crisp shadows, drama, editorial.
- **Rim / backlight** — a bright edge separating subject from background; makes objects pop off dark backgrounds (great for dark-UI hero art).
- **Golden hour** — warm, aspirational, human.
- **High-key** — bright, low-contrast, airy, optimistic. **Low-key** — dark, moody, luxury.
- **Studio three-point** (key + fill + rim) — the reliable "professional" look.

### 2.5 Composition — where things sit
- **Rule of thirds** — subject off-center on a third line; the default for balance.
- **Negative space** — deliberate emptiness; makes a hero feel premium and leaves room for headline text (ask for it explicitly: `…generous negative space on the right for text`).
- **Leading lines** — lines that pull the eye to the subject or CTA.
- **Symmetry / centered** — stable, confident, iconic. **Foreground framing** — adds depth.

### 2.6 Video-only — camera *movement* (for Veo, Kling, Higgsfield, Runway)
- **Push in / dolly in** — slow move toward subject; builds focus. **Pull out** — reveals context.
- **Pan / tilt** — rotate horizontally / vertically from a fixed point.
- **Tracking / follow** — camera moves with the subject. **Orbit / arc** — circle a product (the classic hero spin).
- **Crane / boom** — vertical rise or drop. **Static / locked-off** — no movement; often the most premium choice.
- **Speed:** `slow, smooth, cinematic` beats `fast` for product — name it or models jitter.

### 2.7 How to actually use this with your AI
1. **Stack, don't pile.** One shot size + one angle + one lens/aperture + one lighting + one composition note. Five precise words beat twenty vague ones.
2. **Match the shot to the job.** Hero = negative space + rim light + ¾ or low angle. Founder = 85mm, f/1.8, eye-level, soft light. Feature detail = macro, deep focus.
3. **Lock a look, then reuse it.** When a prompt works, save the camera/lens/lighting string as a preset so every asset matches — consistency reads as "designed."
4. **Never let the shot lie.** If a render shows a capability, screen, or result you don't have, regenerate or cut it.

---

## Section 3 — Copywriting frameworks, named

Most "bad copy" isn't a wording problem — it's a *structure* problem. These are the named structures professionals reach for. Knowing the name lets you ask your AI for the right shape ("write this section as PAS") instead of hoping.

### The message structures
- **PAS — Problem · Agitate · Solution.** State the problem, make it vivid, then present your product as the resolution. Best for pain-driven products and the top of a page. *Relay: "Your demo is rough. Every re-record burns the launch you were about to post. Edit the transcript instead."*
- **AIDA — Attention · Interest · Desire · Action.** The classic funnel in one section: hook, build interest, create want, ask. Good for a full landing narrative.
- **BAB — Before · After · Bridge.** Show life before, paint the after, position the product as the bridge. Great for transformation stories and hero sections.
- **PASTOR — Problem · Amplify · Story · Transformation · Offer · Response.** A longer, story-led structure for sales pages and emails.
- **The 4 Ps — Promise · Picture · Proof · Push.** Promise a benefit, help them picture it, prove it, then push to act. A tidy structure for a single offer block.

### The building blocks
- **Feature → Benefit → Meaning.** Never stop at the feature. *Feature:* edit by transcript. *Benefit:* no timeline. *Meaning:* you ship the demo today instead of next week.
- **The one-line value proposition.** `For [buyer in situation], [product] is the [category] that [outcome], unlike [alternative], because [reason].` The load-bearing sentence of the whole page (this is the book's positioning line).
- **Headline formulas that aren't hype:** the outcome headline ("Ship the demo while the feature is still new"), the how-to ("Turn a rough recording into a launch video"), the objection-first ("Editing without a timeline").

### Voice & tone — describe it on two axes
Pick a position on each and hand it to your AI so output stays consistent:
- **Formal ↔ casual** · **Serious ↔ playful** · **Matter-of-fact ↔ enthusiastic** · **Dry ↔ warm.**
*Relay's voice: casual, matter-of-fact, warm, dry — a competent peer, not a hype machine.*

> **How to use this with your AI:** name the framework and the voice in the prompt — "Write the problem section as PAS, voice: casual + matter-of-fact, banned words: revolutionize/seamless/effortless." Then judge the draft against the book's evidence rules before it ships.

---

## Section 4 — Choosing a design system

A design system (or component library) is the fixed vocabulary your product — and your AI coder — builds from. Choosing one badly means fighting it forever; choosing well means every screen looks consistent for free.

### The decision, in four questions
1. **Adopt, adapt, or create?** (Nielsen Norman Group's framing.) The more custom you go, the more time and money it costs and the more you must maintain. Choose the *least* custom option that meets your needs. Most AI-built indie products should **adopt**.
2. **Own the code, or install a dependency?** Copy-paste systems (shadcn/ui) let you own and edit every component; installed libraries (MUI, Chakra) are faster but harder to bend to your brand.
3. **Styled, or headless?** Styled = it looks good out of the box. Headless (Radix, Base UI) = accessible behavior only, you bring the styling. These aren't competitors — shadcn is *styled components built on a headless engine.*
4. **Does your AI coder already speak it?** The models emit shadcn/Tailwind fluently. Picking the stack your tools already know removes an entire category of friction.

### The verified options (2026)
**Foundations you own / build on**
- **shadcn/ui** — copy-paste, fully-owned React + Tailwind components. The default when you want to own the code. — https://ui.shadcn.com · blocks: https://ui.shadcn.com/blocks
- **Radix UI (Primitives + Colors)** — unstyled accessible primitives; the accessibility engine under much of the ecosystem. *(Acquired by WorkOS; primitive development has slowed.)* — https://www.radix-ui.com · colors: https://www.radix-ui.com/colors
- **Base UI** — unstyled accessible primitives from ex-Radix/MUI engineers; the actively-maintained headless alternative. — https://base-ui.com

**Opinionated / complete systems**
- **Tailwind Plus** *(paid)* — 500+ first-party Tailwind blocks, templates, the Catalyst kit. — https://tailwindcss.com/plus
- **Vercel Geist** — Vercel's own system (color, Geist type, components); ideal in the Next.js world. — https://vercel.com/geist/introduction
- **Material 3** — Google's complete, opinionated spec with dynamic color; Android-first. — https://m3.material.io
- **Untitled UI** — very large Figma kit + open-source React library; when design starts in Figma. — https://www.untitledui.com
- **Park UI** — Ark UI + Panda CSS, framework-agnostic (React/Vue/Solid). — https://park-ui.com

**Ready-made pieces & registries** (extend a shadcn base)
- **21st.dev** — community catalog of components/blocks with AI-ready prompts. — https://21st.dev
- **Aceternity UI** — animated, motion-heavy React components for landings. — https://ui.aceternity.com
- **Magic UI** — 150+ free animated components; a shadcn companion. — https://magicui.design
- **Origin UI** — large copy-paste Tailwind set following shadcn conventions. — https://originui.com
- **HyperUI** — free, MIT, no-install Tailwind blocks. — https://www.hyperui.dev
- **Tremor** — React dashboard & chart components. *(Joining Vercel — check maintenance status.)* — https://tremor.so

### Read before you commit (verified, reputable)
- **Design Systems 101** — Nielsen Norman Group — the adopt/adapt/create decision. — https://www.nngroup.com/articles/design-systems-101/
- **What is the difference between Radix and shadcn/ui?** — WorkOS — headless vs. styled, clearly. — https://workos.com/blog/what-is-the-difference-between-radix-and-shadcn-ui
- **React UI libraries in 2025 (shadcn/Radix/Mantine/MUI/Chakra…)** — Makers' Den — a practical side-by-side. — https://makersden.io/blog/react-ui-libs-2025-comparing-shadcn-radix-mantine-mui-chakra
- **shadcn vs Radix vs Base UI: which should a junior pick in 2026?** — dev.to — why they're layers, not rivals. — https://dev.to/edriso/shadcn-vs-radix-vs-base-ui-which-one-should-a-junior-pick-in-2026-1jml

> **The shortcut for most readers:** adopt **shadcn/ui** + **Radix Colors** for tokens, pull specific pieces from **21st.dev**, add one motion library (**Motion**) and one accent set (**Aceternity/Magic UI**), and restyle everything to your own tokens. Consistent, accessible, and fluent in the language your AI already writes.

---

## Section 5 — Brand core → website

Design isn't decoration you add at the end. It's your brand's decisions, made visible. Here's how to translate a brand core into the screen — and why the hero section carries most of the weight.

### 5.1 From core to visual decisions
Start with three things and let them drive every visual choice:
1. **One buyer, one moment** — who this is for, at the exact moment they need it (from your `POSITIONING.md`).
2. **One belief** — the single thing you want them to believe after the page (your creative direction).
3. **One personality** — three or four adjectives (e.g. *precise, calm, honest*).

Then translate — each brand trait becomes concrete decisions:

| If the brand is… | Type | Color | Motion | Layout |
|---|---|---|---|---|
| **Precise / technical** | grotesk sans, tight scale, mono for data | restrained, few roles, high contrast | fast, minimal, functional | strict grid, dense but ordered |
| **Warm / human** | humanist sans or serif, larger sizes | warmer hues, softer contrast | gentle, eased | generous spacing, rounded |
| **Premium / confident** | editorial serif or spacious sans | near-monochrome + one accent | slow, cinematic | big imagery, lots of negative space |
| **Playful / bold** | display type, big sizes | saturated, more color | springy, characterful | grid-breaking, bento, maximal |

The point isn't the specific mapping — it's that *every* choice traces back to a stated trait. If you can't say which trait a font or color serves, it's decoration; cut it.

### 5.2 The hero section — why it carries the page
The hero is the ~5 seconds that decide whether anyone reads the rest. Most AI-built pages waste it on a vague headline and a stock gradient. A hero has one job: **make a stranger able to say what this is, who it's for, and why it matters — before they scroll.**

**Anatomy of a hero that works:**
- **Eyebrow** *(optional)* — who it's for, in their words. ("For people who shipped — and heard crickets.")
- **Headline** — the outcome or the obvious what-it-is. Not clever; clear. One idea.
- **Subhead** — one sentence adding the mechanism or the "unlike." Answers "how / why you."
- **Primary action** — one, low-risk, and it says what happens next ("Try the sample," not "Get started").
- **Secondary action** *(optional)* — for the not-yet-ready ("See the method").
- **The evidence** — a real product frame, before/after, or demo — visible *without scrolling.* On mobile it must appear before the first major scroll.
- **A trust line** — the concrete specifics ("124 pages · the AI-context files · 7-day refund").

**Hero rules of thumb:** one primary action (a second competing CTA lowers both). No hero *number* unless evidence sits beside it — a bare stat reads as a claim. Negative space is not wasted space; it's what makes the one idea land. And the image must be the *real* product — a hero that shows a capability you don't have is the most expensive kind of lie.

> **How to use this with your AI:** write the hero last, after positioning and proof are decided. Give the model the buyer, the one belief, the personality adjectives, and the real evidence asset — then ask for three headline options in each of three structures (outcome, how-to, objection-first) and judge them against the five-second test.

---

## Section 6 — Quick glossary

A fast reference for the terms used across this guide and the book. For the full picture, see the section noted.

**Design languages** *(§1)* — **Glassmorphism:** frosted translucent panels. **Neo-brutalism:** thick borders, hard shadows, raw color. **Bento grid:** modular different-sized feature cards. **Swiss/editorial:** grid- and type-first modernism. **Dark luxury:** near-black, sparse, atmospheric. **Y2K/retro-futurism:** retro-OS nostalgia. **Big-type maximalism:** oversized type as the visual. **Claymorphism:** soft puffy 3D shapes.

**Image & video** *(§2)* — **Shot size:** how much frame the subject fills (wide→macro). **Angle:** where the lens sits (eye-level, low, high, ¾, dutch, overhead). **Focal length:** lens character (35/50/85/100mm). **Aperture (f-stop):** depth of field; low f = blurred background (**bokeh**). **Rim light:** bright edge that separates subject from background. **Three-point lighting:** key + fill + rim. **Negative space:** deliberate emptiness. **Locked-off:** static camera. **Orbit:** camera circles the subject.

**Copywriting** *(§3)* — **PAS:** Problem–Agitate–Solution. **AIDA:** Attention–Interest–Desire–Action. **BAB:** Before–After–Bridge. **Value proposition:** the one-line "for X, product is the Y that Z, unlike A, because B." **Feature vs. benefit:** what it does vs. what that gets you. **Voice/tone:** the consistent personality of the words.

**Design systems** *(§4)* — **Design system:** the fixed vocabulary of components + tokens. **Design tokens:** named variables for color/space/type (e.g. `--action`). **Headless / unstyled:** accessible behavior without styling (Radix, Base UI). **Copy-paste components:** code you own and edit (shadcn/ui). **Registry:** a catalog you install pieces from (21st.dev).

**Product page** *(from the book)* — **Hero:** the above-the-fold decision moment *(§5)*. **Threshold:** a point a visitor must clear (attention, comprehension, relevance, trust, action). **Proof / evidence confidence (0–5):** how strong a claim's support actually is. **Positioning:** the one buyer, one moment, one reason to choose. **Bento / comparison / pricing card:** standard page blocks (illustrated in the book's figures).

---

*Every link verified 2026-07-31. Tools and trends move — re-verify before you depend on one, and confirm every license and commercial-use term yourself. The parts are real; keeping them honest is your job.*
